from pathlib import Path
import csv, hashlib, json, re, statistics, subprocess, zipfile

repo=Path.cwd();root=repo/'shots/projectile_scaling_20261012'
old=repo/'shots/environment_stage2_optimization'
destination=repo/'docs/validation/projectile_scaling_20261012';destination.mkdir(parents=True,exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return path.read_text(encoding='utf-8-sig')
def rows(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream))
report={'baselineCommit':'d15d525','scope':'Projectile broadphase; unchanged 60Hz simulation / 240Hz collisions, weapons, roster and AI',
        'profiles':[],'scale':[],'matrix':[],'fps':{},'checks':{}}
for group in (1,2,4,10):
    variants={v:[json.loads(read(root/f'scale-{group}-{repeat}-{v}.json'))[0] for repeat in (1,2,3)] for v in ('before','after')}
    assert len({x['summarySha256'] for items in variants.values() for x in items})==1,(group,'scale outcome changed')
    stats={v:{key:statistics.median(x[key] for x in items) for key in ('meanMs','p95Ms','p99Ms','allocatedBytesPerTick','peakRails','peakMissiles','peakProbes')} for v,items in variants.items()}
    for v,items in variants.items():
        stats[v]['sectionsUs']={k:statistics.median(x['sectionsUs'][k] for x in items) for k in items[0]['sectionsUs']}
        stats[v]['meanMsRange']=[min(x['meanMs'] for x in items),max(x['meanMs'] for x in items)]
    report['scale'].append(dict(ships=24*group,groupsPerSide=group,repeats=3,resultsIdentical=True,**stats))
def profile(label):
    ticks={r['scope']:r for r in rows(root/(label+'.ticks.csv'))}
    sections={r['section']:float(r['usPerTick']) for r in rows(root/(label+'.sections.csv')) if r['scope']=='All'}
    return dict(meanMs=float(ticks['All']['meanMs']),brawlP99Ms=float(ticks['Brawl']['p99Ms']) if ticks.get('Brawl',{}).get('p99Ms') else None,sectionsUs=sections)
for mode in ('Annihilation','Flagship','Domination'):
    for field in (0,1,2,3):
        prefix=f'profile-{mode}-field{field}-'
        report['profiles'].append(dict(mode=mode,field=field,before=profile(prefix+'before'),after=profile(prefix+'after')))
        label=f'final-{mode}-field{field}'
        assert 'PASS: 20/20 battle summaries match' in read(root/(label+'.log'))
        matching={}
        for suffix in ('summaries.json','ships.csv','am.csv','probes.csv','environment.csv','environment-events.csv','sight.csv','cover.csv','navigation.csv'):
            a,b=old/(label+'.'+suffix),root/(label+'.'+suffix)
            if suffix=='navigation.csv':
                normalize=lambda p:[{k:v for k,v in r.items() if k not in ('buildMs','planMs')} for r in rows(p)]
                matching[suffix]=normalize(a)==normalize(b)
            else:matching[suffix]=a.read_bytes()==b.read_bytes()
            assert matching[suffix],(label,suffix)
        report['matrix'].append(dict(mode=mode,field=field,battles=20,matches=matching))
report['stage1DeepSpaceMatches']={}
for mode in ('Annihilation','Flagship'):
    assert (repo/f'shots/environment_stage2/baseline-{mode}.summaries.json').read_bytes()==(root/f'final-{mode}-field0.summaries.json').read_bytes()
    report['stage1DeepSpaceMatches'][mode]=20
report['summaryMatches']=sum(r['battles'] for r in report['matrix'])
report['pairedBlock']=json.loads(read(root/'final-inprocess-block.json'))
assert len(report['pairedBlock'])==5
for path in (root/'final-sim.log',root/'native-flow-test.log',root/'native-environment-test.log'):
    text=read(path);assert 'PASS:' in text and not re.search('Unhandled exception|ERROR:',text)
    checks=re.findall(r'PASS: (\d+) ([^\r\n]+)',text)
    report['checks'][path.name]=dict(total=sum(int(n) for n,_ in checks),groups=checks)
for path in root.glob('fps-*.log'):
    text=read(path);assert not re.search('ERROR:|Exception',text)
    samples=[dict(time=int(t),fps=float(f)) for t,f in re.findall(r'perf t=(\d+)s fps=([\d.]+)',text) if 590<=int(t)<=615]
    assert samples,path
    report['fps'][path.name]=dict(mean=statistics.mean(x['fps'] for x in samples),minimum=min(x['fps'] for x in samples),samples=samples,build=re.search('perf build:.*',text).group())
assert len(report['fps'])==4
report['releasePairedFps']={}
for mode in ('Annihilation','Domination'):
    text=read(root/f'release-pair-before-{mode}.log')
    assert not re.search('ERROR:|Exception',text)
    samples=[dict(time=int(t),fps=float(f)) for t,f in re.findall(r'perf t=(\d+)s fps=([\d.]+)',text) if 590<=int(t)<=615]
    before=dict(mean=statistics.mean(x['fps'] for x in samples),minimum=min(x['fps'] for x in samples),samples=samples)
    after=report['fps'][f'fps-Release-{mode}.log']
    report['releasePairedFps'][mode]=dict(before=before,after=after,meanChangePercent=(after['mean']/before['mean']-1)*100)
frozen=json.loads(read(root/'sim-source-hashes.json'))
assert all(sha(Path(x['path'])).lower()==x['sha256'].lower() for x in frozen),'Simulation changed after benchmark freeze'
report['sources']={str(p.relative_to(repo)).replace('\\','/'):sha(p) for folder in ('src','tests/SimChecks','tools/ScaleBench') for p in (repo/folder).rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
for p in list((repo/'data/ships').glob('*.json')) + list((repo/'src/Sim').glob('*.cs.uid')) + [repo/'SpaceFleet.csproj',repo/'src/Sim/SpaceFleet.Sim.csproj',repo/'tools/ScaleBench/ScaleBench.csproj']:
    report['sources'][str(p.relative_to(repo)).replace('\\','/')]=sha(p)
assert subprocess.run(['git','diff','--quiet','d15d525','--','data/ships'],cwd=repo).returncode==0
report['shipDataUnchangedFromBaseline']=True
report['runnerHashes']={name:sha(path) for name,path in {'baseline':old/'runner/BattleBatch.dll','current':root/'runner/BattleBatch.dll','scaleBefore':root/'scale-before/ScaleBench.dll','scaleAfter':root/'scale-after/ScaleBench.dll'}.items()}
build=repo/'builds/SpaceFleet-20261012-projectile-scaling-Windows-x64'
archive=build.with_suffix('.zip')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert any(p.endswith('/SpaceFleet.Sim.dll') for p in z.namelist())
report['build']=json.loads(read(build/'build-info.json'))
report['build'].update(zipSha256=sha(archive),zipBytes=archive.stat().st_size,zipCrcVerified=True)
report['nativeExportChecks']=sum(int(n) for line in report['build']['checks'] for n in re.findall(r'PASS: (\d+)',line))
report['build']['assemblyHashes']={p.name:sha(p) for p in build.rglob('SpaceFleet*.dll')}
report['limitations']=[
    'Scale scenarios are synthetic Earth/Earth DeepSpace fights in one shared world, 40 km start, 15 s warmup + 60 s measured, three isolated repetitions. Not multiplayer/render/network FPS.',
    '24/48/96/240 ships assume 1/2/4/10 canonical 12-ship groups per side; final player squad size is not specified.',
    'Per-tick latency includes the profiler. Separate six-job 240-battle validation is not used for performance conclusions.',
    'Large-scene terrain, prolonged debris, other designs and hardware, network costs and manual play feel are unverified.',
    'Preliminary scale measurements identified a remaining carrier scan; the second preliminary repetition was deliberately stopped. Only final root-level scale data feeds this report.',
    'Navigation comparison excludes nondeterministic buildMs and planMs only.'
]
evidence=[]
for p in root.rglob('*'):
    if p.is_file() and p.suffix in ('.log','.json','.csv','.ps1','.py') and not {'obj','bin','detail','baseline-source'}.intersection(p.relative_to(root).parts):
        evidence.append((p,'run/'+str(p.relative_to(root))))
for p in old.glob('final-*'):
    if p.suffix in ('.csv','.json'):evidence.append((p,'baseline/'+p.name))
for p in (repo/('shots/'+build.name)).glob('*.log'):
    assert not re.search('ERROR:|Exception',read(p)),p
    evidence.append((p,'export/'+p.name))
with zipfile.ZipFile(destination/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in evidence:z.write(p,name)
    z.write(repo/'shots/environment_stage1/paired-block/Program.cs','paired-block/Program.cs')
report['evidenceSha256']=sha(destination/'evidence.zip')
(destination/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:report[k] for k in ('scale','fps','summaryMatches','checks','nativeExportChecks')},ensure_ascii=False,indent=2))
