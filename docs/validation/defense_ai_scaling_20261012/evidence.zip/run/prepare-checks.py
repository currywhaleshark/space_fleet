from pathlib import Path
s=Path('shots/defense_ai_scaling_20261012/baseline-source/SimMissiles.cs').read_text(encoding='utf-8')
s=s[s.index('    private void StepPointDefense('):s.index('    private static float Roll(')]
s=s.replace('private void StepPointDefense(', 'private void ReferencePointDefense(')
d=Path('shots/defense_ai_scaling_20261012/baseline-source/DefenseDrones.cs').read_text(encoding='utf-8')
d=d[d.index('    private void StepDefenseDrones('):d.rindex('}')].replace('private void StepDefenseDrones(', 'private void ReferenceDefenseDrones(')
header='''// Frozen 36a7254 exhaustive PD traversal. Test only; preserves selection,
// slew, firing, damage and same-substep removals for exact comparison.
using System;
using System.Linq;
using Godot;
namespace SpaceFleet.Sim;
public sealed partial class SimWorld
{
    internal TerrainExposure PlanningForCheck(Faction side) => PlanningExposure(side);
    internal void DefenseForCheck(double time, bool reference)
    { if(reference) { ReferencePointDefense(TickDelta/4,time); ReferenceDefenseDrones(TickDelta/4,time); }
      else { StepPointDefense(TickDelta/4,time); StepDefenseDrones(TickDelta/4,time); _pdTargetsPrepared=false; } }
    internal void ThreatTimeForCheck(long tick) { Tick=tick; PrepareAIThreats(); }
    internal bool IndexedThreatForCheck(ShipBody ship,float range) => IncomingMissileThreat(ship,range);
    internal bool ReferenceThreatForCheck(ShipBody ship,float range) => Sensors.SmallContacts(ship.Faction)
        .Any(t=>t.Kind==SmallContactKind.Missile && t.Fresh(Time)
            && (t.Predict(Time)-ship.Position).Length()<range && Threatens(t,ship,out _));
'''
tail='''}
public sealed partial class SensorNet
{
    internal void SetSmallForCheck(Faction faction,SmallContact contact) => _smallContacts[(faction,contact.Target)]=contact;
}
'''
Path('tests/SimChecks/DefenseReference.cs').write_text(header+d+s+tail,encoding='utf-8')
