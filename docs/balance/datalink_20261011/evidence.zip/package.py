import collections, csv, hashlib, json, pathlib, zipfile

root=pathlib.Path('shots/datalink-20261011')
before=pathlib.Path('shots/damage-control-20261011')
out=pathlib.Path('docs/balance/datalink_20261011'); out.mkdir(parents=True,exist_ok=True)
names=['Earth-Mars','Mars-Earth']
analysis={}
for label,folder in [('before',before),('after',root)]:
    wins=collections.Counter(); ships=[]
    for name in names:
        blue,red=name.split('-')
        with (folder/(name+'.csv')).open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        assert {(r['seed'],r['mirror']) for r in rows}=={('1','0'),('1','1'),('2','0'),('2','1')}
        for row in rows:
            w=row['winner']; wins[blue if w=='Blue' else red if w=='Red' else w]+=1
        with (folder/(name+'.ships.csv')).open(encoding='utf-8-sig',newline='') as f:
            ships.extend(s for s in csv.DictReader(f) if s['design']=='Earth' and s['kind']=='Battleship')
    analysis[label]={'wins':dict(wins),'earth_battleships':len(ships),'firing_ships':sum(int(s['rails'])>0 for s in ships),
        'shots':sum(int(s['rails']) for s in ships),'hits':sum(int(s['railHits']) for s in ships)}
(out/'analysis.json').write_text(json.dumps(analysis,indent=2),encoding='utf-8')
files={}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    def add(name,path):
        data=path.read_bytes(); archive.writestr(name,data); files[name]=hashlib.sha256(data).hexdigest()
    for label,folder in [('before',before),('after',root)]:
        for name in names:
            for suffix in ['.csv','.ships.csv','.am.csv','.telemetry.csv','.summaries.json','.log']:
                p=folder/(name+suffix); add(label+'/'+p.name,p)
    add('package.py',root/'package.py')
    for name in ['datalink-simchecks.log','datalink-weapon-input.log','datalink-hud.log','datalink-hud.png']:
        add('checks/'+name,pathlib.Path('shots')/name)
paths=sorted([*pathlib.Path('src/Sim').glob('*.cs'),*pathlib.Path('src/Game').glob('*.cs'),
    *pathlib.Path('tests/SimChecks').glob('*.cs'),*pathlib.Path('data/ships').glob('*.json'),*pathlib.Path('tools/BattleBatch').glob('*.cs')])
manifest={'runs':8,'seeds':[1,2],'mirror':True,'minutes':25,'teams':names,
    'baseline':'damage_control_20261011; emergency repairs enabled, before linked fire-control correction',
    'command':'dotnet tools/BattleBatch/bin/Release/net8.0/BattleBatch.dll --seeds 1,2 --mirror --jobs 2 --minutes 25 --blue-design <Earth|Mars> --red-design <Mars|Earth> --telemetry --output <path>',
    'source_sha256':{p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
    'evidence_sha256':files,'archive_sha256':hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(out/'evidence.zip') as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(k)).hexdigest()==v for k,v in files.items())
print('Verified',len(files),'files;',analysis)
