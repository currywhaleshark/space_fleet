$sfChecks = @()
foreach ($sfTest in @('flow-test','model-test','combat-visual-test','audio-test','fleet-audio-test','weapon-input-test','telescope-test','contact-test','sensor-coverage-test','am-game-test','environment-test')) {
    $sfLog = Join-Path $sfLogs "$sfTest.log"
    $sfProcess = Start-Process -FilePath $sfExe -WorkingDirectory $sfOutput -WindowStyle Hidden -PassThru -ArgumentList @('--fixed-fps','60','--log-file',('"'+$sfLog+'"'),'--',"--$sfTest",'--seed=1')
    if (!$sfProcess.WaitForExit(120000)) { Stop-Process -Id $sfProcess.Id; throw "Exported $sfTest timed out." }
    $sfText = Get-Content -LiteralPath $sfLog -Encoding UTF8 -Raw
    if ($sfProcess.ExitCode -ne 0 -or $sfText -match 'ERROR:|Exception' -or $sfText -notmatch 'PASS:') { throw "Exported $sfTest failed: $sfLog" }
    $sfPass = ($sfText -split "`n" | Where-Object { $_ -match 'PASS:' }).Trim()
    $sfChecks += $sfPass
    Write-Output $sfPass
}
$sfInfo = [ordered]@{
    name=$Name; builtAt=[DateTimeOffset]::Now.ToString('o'); engine=(Get-Content -LiteralPath (Join-Path $sfLogs 'export.log') -Encoding UTF8 -TotalCount 1).Trim()
    sourceCommit=(& git -C $ProjectDir rev-parse HEAD).Trim(); localChanges=[bool](& git -C $ProjectDir status --porcelain)
    platform='Windows x64'; selfContained=$true; checks=$sfChecks
}
$sfInfo | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $sfOutput 'build-info.json') -Encoding UTF8
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sfArchive = Join-Path $sfRoot "$Name.zip"
[IO.Compression.ZipFile]::CreateFromDirectory($sfOutput,$sfArchive,[IO.Compression.CompressionLevel]::Optimal,$true)
$sfDigest = (Get-FileHash -LiteralPath $sfArchive -Algorithm SHA256).Hash.ToLowerInvariant()
"$sfDigest  $Name.zip" | Set-Content -LiteralPath "$sfArchive.sha256" -Encoding ASCII
Write-Output "Executable: $sfExe"
Write-Output "Archive: $sfArchive"

