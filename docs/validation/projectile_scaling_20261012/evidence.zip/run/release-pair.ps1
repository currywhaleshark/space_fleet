$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/projectile_scaling_20261012'
foreach($mode in @('Annihilation','Domination')) {
 $seed=if($mode -eq 'Annihilation'){1}else{5}
 foreach($variant in @('before','after')) {
  $name=if($variant -eq 'before'){'SpaceFleet-20261012-environment-stage2-optimized-Windows-x64'}else{'SpaceFleet-20261012-projectile-scaling-Windows-x64'}
  $build=Join-Path (Get-Location).Path ('builds/'+$name)
  $file=if($variant -eq 'before'){'release-pair-before-'+$mode+'.log'}else{'fps-Release-'+$mode+'.log'}
  $log=Join-Path $root $file
  if($variant -eq 'after'){Copy-Item -LiteralPath $log -Destination (Join-Path $root ('preliminary/'+$file))}
  $arguments=@('--log-file',('"'+$log+'"'),'--','--autoplay','--autoplay-speed=4',('--seed='+$seed),'--blue-design=Earth','--red-design=Earth',('--objective='+$mode),'--battlefield=AsteroidCluster','--field-seed=2','--advance=540','--perf-trace','--perf-seconds=40','--perf-no-sim-profile')
  $child=Start-Process -FilePath (Join-Path $build 'SpaceFleet.exe') -ArgumentList $arguments -WorkingDirectory $build -WindowStyle Hidden -PassThru
  if(-not $child.WaitForExit(300000)){Stop-Process -Id $child.Id -Force;throw 'Our paired FPS run timed out'}
  $text=Get-Content -LiteralPath $log -Raw -Encoding UTF8
  if($child.ExitCode -ne 0 -or $text -match 'ERROR:|Exception' -or $text -notmatch 'perf t='){throw ('FPS pair failed '+$file)}
  Write-Output ('Measured '+$variant+' '+$mode)
 }
}
