import json, statistics
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[1]
r=json.loads((repo/'docs/validation/environment_stage2_optimization_20261012/verification.json').read_text(encoding='utf-8'))
names={'Annihilation':'섬멸','Flagship':'기함','Domination':'점령'}
def p99(x):return '—' if x is None else f'{x:.3f}'
rows=[]
for p in r['profiles']:
    s=p['after']['sections']
    rows.append(f"| {names[p['mode']]}/{p['field']} | {p['before']['meanUs']:.3f}→{p['after']['meanUs']:.3f} | {p['changePercent']:.1f}% | {p['deep']['meanUs']:.3f} / {p['ratio']:.3f} | {p99(p['before']['brawlP99Ms'])}→{p99(p['after']['brawlP99Ms'])} | "+'/'.join(f'{s[k]:.2f}' for k in ('Collision','TerrainCollision','Sensors','AIThink','Projectiles'))+' |')
fps=[]
for mode,oldmean,oldmin in [('Annihilation',15.2,7.4),('Domination',4.1,3.5)]:
    d=r['fps'][f'final-debug-{mode}.log'];release=r['fps'][f'final-release-{mode}.log']
    fps.append(f"| {names[mode]} | {oldmean:.1f}/{oldmin:.1f} | {d['mean']:.1f}/{d['minimum']:.1f} | {release['mean']:.1f}/{release['minimum']:.1f} |")
a=statistics.median(x['baselineUs'] for x in r['pairedBlock']); b=statistics.median(x['currentUs'] for x in r['pairedBlock'])
text='''

## 追加 최적화 (2026-10-12)

사용자의 “최적화부터” 지시에 따라 6차 성능 미달을 후속 개선했다. 기준 소스는 `eeb7927`이다. 전투 수치, 60Hz/240Hz 갱신, double 위치, 센서 정보 공개 규칙은 변경하지 않았다.

### 구현과 채택 근거

- `ObstacleBvh`: 회전된 실제 구·캡슐 경계로 AABB를 만들고, 짧은 물리 질의는 AABB 겹침과 4km 정적 셀 후보를 사용한다. 큰 좌표·지나치게 큰 지형은 기존 BVH 경로로 돌아간다. 원래 삽입 순서와 실제 충돌 판정은 유지한다.
- `ObstacleCollision`, `DamageRay`: 오래된 잔해를 구성하는 조각 그룹의 경계로 빈 공간을 먼저 제외한다. 개별 상자 판정과 동점 순서는 보존한다. 6함체 × 원점/±1e12m × 파괴 후 0/30/900/10000초의 충돌 144건, 광선 14,400건을 이전 수식과 직접 대조했다.
- `SmallContactSensors`, `SensorNet`: 탐지 하한에도 못 미치거나 이미 확보한 관측보다 약한 소형 표적 신호는 지형 시선 검사를 생략한다. 엄폐가 없는 ECM 지원 세기가 0이면 별도 가림 계산도 생략한다. 탐지 임계값·히스테리시스·가림 기억은 바꾸지 않았다.
- `SpaceFleet.Sim.csproj`: 수치 계산부를 별도 최적화 어셈블리로 옮겼다. **Debug 게임/입력/렌더는 기존 비최적화 상태이고, Sim만 최적화된다.** portable PDB를 유지하며 `-p:SimOptimize=false`로 계산부까지 비최적화해 디버깅할 수 있다. 이 빌드 설정 변경이 Debug FPS 향상에 크게 기여하므로 알고리즘만의 효과로 표현하지 않는다. `PerfTrace` 로그에 두 어셈블리의 실제 MinOpts 속성을 남긴다.
- `BattleBatch --slow-ticks`: 느린 128개 틱의 구간별 비용을 별도 CSV로 보존한다. 진단 옵션의 추가 비용을 정식 성능 측정에 섞지 않았다.

채택하지 않은 시도도 원자료에 남겼다. 잔해 조각마다 BVH를 다시 질의하는 방식은 전체 선체 후보를 한 번 얻는 방식보다 느려서 제거했다. 소형 표적 상대 궤적에 축별 사전 검사를 넣은 후보는 심우주 교차 측정에서 2.1~4.5% 느려져 제거했다. 사용자 게임이 동시 실행됐던 pass5/pass6/detail 자료는 성능 판정에서 제외하고, 게임 종료 확인 후 최종 측정을 다시 했다.

### 최종 성능

Release `BattleBatch`, jobs=1, 전투 시드 1. 목표·배치마다 현재 심우주 → 변경 전 소행성 → 변경 후 소행성을 순차 실행했다. 이 구간에는 다른 검증 배치·빌드·게임을 실행하지 않았다. 각 조합 1회이므로 반복 측정의 신뢰구간을 뜻하지 않으며, OS 부하·클럭 변동은 남아 있다. 앞선 6차와 수치가 다른 변경 전 대조군도 이번에 다시 측정한 값 그대로 보고한다.

| 목표/배치 | 전후 평균 µs/틱 | 변화 | 현재 심우주 µs / 소행성 배율 | 난전 p99 전후(ms) | 변경 후 충돌/그중 지형/센서/AI 판단/탄체 µs |
|---|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+f'''

빈 심우주의 공식 교차 비교는 1단계 기준 `6629d2e`와 최종 실행기다. CPU affinity 4, 120틱 교차, 1쌍 예열 후 5쌍 측정. 중앙값 **{a:.3f}→{b:.3f}µs ({100*(b/a-1):+.3f}%)**로 ±1% 기준을 통과했다. 개별 반복의 차이와 예열값도 모두 보존했다. 모든 반복 요약이 같으며, `no-small-runner`라는 실험 이름으로 측정한 DLL과 최종 배치 DLL의 SHA-256이 동일하다.

| 실제 게임 ×4 · 590~615초 표본 | 이전 Debug 평균/최소 FPS | 현재 Debug 평균/최소 FPS | 현재 배포 Release 평균/최소 FPS |
|---|---:|---:|---:|
'''+ '\n'.join(fps)+f'''

RTX 2060·i7-10750H·1600×900·Vulkan Forward+, 렌더·음향 ON. 소행성 배치 2, Earth/Earth, 섬멸 시드 1·점령 시드 5. 540초부터 시작해 40초 실시간 관전, fixed-fps 없음. 현재 Debug는 `gameMinOpts=True/simMinOpts=False`, Release는 둘 다 False인 로그를 확인했다. 시뮬레이션과 게임 창 모두 동시 성능 부하 없이 측정했다. 평균은 구간 내 약 1초 간격 표본의 산술평균이며, 이 두 장면이 모든 전황의 최저 FPS를 보장하지는 않는다.

**성능 완료 판정은 일부 보류한다.** 평균 소행성/심우주 배율과 위 Debug 장면의 30 FPS 기준은 통과했다. 점령전 일부 배치의 난전 p99는 여전히 1ms를 넘는다. 별도 느린 틱 진단의 난전 표본 {r['slowTickDiagnostic']['brawlRetained']}개 중 {r['slowTickDiagnostic']['dominantSections'].get('Projectiles',0)}개에서 가장 큰 구간은 탄체 처리였다. 후속 대상은 탄체와 소형 표적/잔해의 충돌 후보 축소다. 진단의 가장 느린 128개 표본을 전체 틱의 평균 기여율로 해석하지 않는다. 지시서 5절에 따라 남은 p99 목표를 합격으로 처리하지 않고 사용자 판단 대상으로 남긴다.

### 결과 보존·실행본

- 최종 전체 SimChecks **{r['checks']['final-sim.log']['total']:,}개**, Debug 장면 51개·환경 204개, 배포 EXE 11개 검사군 **{r['nativeExportChecks']:,}개** 통과.
- 3목표 × 심우주/소행성 배치 1·2·3 × 전투 시드 1~10 × 정/역배치 = **240판**. 모든 전투 요약과 함선·AM·프로브·환경 사건·사선·엄폐 CSV가 `eeb7927`의 결과와 바이트 단위로 같다. 경로 CSV는 실제 소요시간인 `buildMs`/`planMs` 두 열을 제외한 모든 값이 같다. 회귀 배치는 jobs=6이며 이때의 wall 시간은 성능 자료로 사용하지 않았다. 심우주 섬멸/기함 40판의 1단계 기준 불변성도 이어진다.
- 실행본: `builds/SpaceFleet-20261012-environment-stage2-optimized-Windows-x64/SpaceFleet.exe` 및 동일 이름 ZIP. Sim DLL·독립 .NET 런타임 포함, 중간 bin/obj 리소스 제외, ZIP 전체 CRC 확인.
- ZIP SHA-256: `{r['build']['zipSha256']}`.
- `validation/environment_stage2_optimization_20261012/verification.json`에 최종 소스·실행기·실행본 해시, `evidence.zip`에 전후 프로파일·모든 교차 반복·240전 대조·실제 FPS·검사·실패한 실험을 보존했다.
- Debug 빌드는 오류 0개이며 NuGet 취약성 피드에 연결하지 못한 NU1900 경고 2개가 있었다. 패키지·검사 실행은 성공했고 경고를 숨기거나 감사 기능을 끄지 않았다.
- 배포 검사 첫 시도에서 전투 시각 검사 프로세스가 엔진 첫 로그를 쓰기 전에 45초 시작 제한에 걸렸다. 그 기록을 보존하고 회귀 배치 종료 후 같은 실행본의 11개 검사를 모두 단독 재실행했다(시작 제한 120초). 첫 실패를 통과로 집계하거나 검사를 생략하지 않았다.
- 수동 비행·카메라·엄폐 체감, 추진계 손상함의 정체 4건, 더 큰 표본의 전장 공정성은 이번 최적화의 검증 범위 밖이다.
'''
text=text.replace('## 追加 최적화','## 추가 최적화')
path=repo/'docs/ENVIRONMENT_stage2.md'
before=path.read_text(encoding='utf-8-sig')
assert '## 추가 최적화 (2026-10-12)' not in before
path.write_text(before.rstrip()+text,encoding='utf-8')
plan=repo/'docs/PLAN.md'
plan.write_text(plan.read_text(encoding='utf-8-sig').rstrip()+f'''

### 전장 환경 2단계 추가 최적화 (2026-10-12)

- [x] 실제 지형 AABB/짧은 질의 셀 후보, 잔해 그룹 충돌·광선 제외, 소형 접촉 시선 검사 생략. 전투 수치·센서 규칙·60/240Hz 유지.
- [x] Debug 게임과 최적화 Sim 어셈블리 분리, PDB·비최적화 디버깅 선택 유지. 실제 빌드 설정을 FPS 로그에 명시.
- [x] 전체 SimChecks {r['checks']['final-sim.log']['total']:,}개·배포 검사 {r['nativeExportChecks']:,}개. 240판 요약 및 상세 전투 기록 전후 일치(경로 생성/탐색 실제 소요시간 제외).
- [x] 빈 공역 교차 중앙값 {a:.3f}→{b:.3f}µs ({100*(b/a-1):+.3f}%), 소행성 평균 배율 기준 및 Debug ×4 10분 장면 30 FPS 기준 통과.
- [ ] 점령전 일부 배치 난전 p99 1ms 기준은 미달. 탄체 처리의 추가 최적화/잔여 기준 사용자 판단 필요. 수동 체감 미확인.
- 실행본: `builds/SpaceFleet-20261012-environment-stage2-optimized-Windows-x64/SpaceFleet.exe`. 결과: `docs/ENVIRONMENT_stage2.md` 추가 최적화 절, 원자료: `docs/validation/environment_stage2_optimization_20261012/`.
''',encoding='utf-8')
print('Updated environment report and plan')
