from pathlib import Path
import json,statistics

p=Path('docs/validation/defense_ai_scaling_20261012/verification.json')
r=json.loads(p.read_text(encoding='utf-8'))
title='2026-10-12 — 방공·AI 관측·대규모 지형 검색 최적화'
fmt=lambda x: '—' if x is None else f'{x:.3f}'
lines=[f'\n\n## {title}\n',
'기준은 `36a7254`. 기본 편성·함선 JSON·무장 수치·판정 주기·AI 전술을 바꾸지 않고 후보 수집과 반복 계산을 줄였다. 60Hz 시뮬레이션, 240Hz 연속 판정과 double 좌표는 유지한다.\n',
'- `DefenseBroadphase.cs`, `SimMissiles.cs`, `DefenseDrones.cs`: 48척 이상에서 진영별 후보 인덱스를 만든다. 미사일 이동/신관 처리 뒤의 위치를 쓰며 PD와 드론이 같은 목록을 공유한다. 후보는 원래 순서대로 검사하고 앞선 포대가 격추·파괴한 대상은 실시간 상태로 다시 거른다. 작은 전투와 극단 좌표는 전체 순회를 유지한다.\n',
'- `AIThreats.cs`, `SimAI.cs`: 한 AI 틱 동안 신선한 센서 관측의 미사일 위치를 공유한다. 실제 미사일 위치·건전성으로 관측을 보정하지 않으며, 원래의 거리/접근 판정을 그대로 수행한다.\n',
'- `SensorNet.cs`: 기존 관측보다 약하고 잠금 소실/접촉 기억에도 영향을 줄 수 없는 관측함의 지형 광선만 생략한다. 신호·관측함 선택·동률 순서·관측 시각은 유지한다.\n',
'- `TerrainExposure.cs`, `SimTerrainNavigation.cs`: 아군 경로 탐색이 같은 관측의 노출도 계산을 공유한다. 틱을 넘겨 재사용할 때는 모든 관측/기억 예측 좌표와 불변 장애물 객체가 정확히 일치해야 한다. 16,384 표본 기준은 캐시 재사용에만 적용하며 탐색량·경로 결과를 제한하지 않는다.\n',
'**규모별 단독 측정**\n',
'각 진영 12척 편성을 1/2/4/10개 배치한 하나의 전장. 심우주·40km 시작·15초 준비+60초 측정·세 반복이며 전후 실행 순서를 번갈아 바꿨다. 표는 중앙값이다. 프로파일러 포함, 렌더·음향·네트워크 제외.\n',
'| 총 척수 | 평균 ms 전→후 | p99 ms 전→후 | 최대 동시 탄체/미사일 |\n|---|---:|---:|---:|\n']
for s in r['scale']:
    a,b=s['before'],s['after']
    lines.append(f"| {s['ships']} | {a['meanMs']:.3f} → {b['meanMs']:.3f} | {a['p99Ms']:.3f} → {b['p99Ms']:.3f} | {int(b['peakRails'])}/{int(b['peakMissiles'])} |\n")
s=r['scale'][-1];a,b=s['before'],s['after']
lines.append(f"\n240척 평균 비용 감소는 {(1-b['meanMs']/a['meanMs'])*100:.1f}%. 평균 구간 비용은 PD {a['sectionsUs']['PointDefense']/1000:.3f}→{b['sectionsUs']['PointDefense']/1000:.3f}ms, AI {a['sectionsUs']['AI']/1000:.3f}→{b['sectionsUs']['AI']/1000:.3f}ms, 드론 {a['sectionsUs']['Drones']/1000:.3f}→{b['sectionsUs']['Drones']/1000:.3f}ms다. 틱당 할당은 {a['allocatedBytesPerTick']/1024:.1f}→{b['allocatedBytesPerTick']/1024:.1f}KiB.\n")
pair=r['pairedBlock']
lines.append(f"\n짧은 24/48척 시험의 일부 지표는 실행 편차나 준비 비용 때문에 상승할 수 있으므로 모든 지표의 개선으로 해석하지 않는다. 별도의 심우주 섬멸 전투 전체를 CPU affinity 4, 120틱 교차, 준비 1쌍+측정 5쌍으로 비교했다. 평균 중앙값 {statistics.median(x['baselineUs'] for x in pair):.3f}→{statistics.median(x['currentUs'] for x in pair):.3f}µs/틱, 쌍별 변화율 중앙값 {statistics.median(x['deltaPercent'] for x in pair):+.3f}%다.\n")
lines+=['\n**240척 추가 조건**\n','| 조건 | 평균 ms 전→후 | p99 ms 전→후 | 최악 ms 전→후 |\n|---|---:|---:|---:|\n']
for case,label in [('asteroid','소행성 시드 2, 15~75초'),('late','심우주 후반, 180~240초')]:
    x=r['extendedScale'][case];a,b=x['before'],x['after']
    lines.append(f"| {label} | {a['meanMs']:.3f} → {b['meanMs']:.3f} | {a['p99Ms']:.3f} → {b['p99Ms']:.3f} | {a['maxMs']:.3f} → {b['maxMs']:.3f} |\n")
lines.append('\n추가 조건은 전후 한 쌍이다. 소행성의 경로 탐색 집중 구간과 순간 최악 지연까지 16.67ms 이하를 보장하지 않는다. 240척 실제 렌더·음향·멀티플레이 비용은 이 측정에 포함되지 않는다.\n')
slow=r['slowDiagnostic']['slowTicks'][0]
lines.append(f"\n별도 세부 계측에서 가장 느린 틱은 {slow['tick']}번(약 {slow['tick']/60:.2f}초), 전체 {slow['ms']:.2f}ms 중 경로 탐색이 {slow['sectionsUs']['NavigationPlan']/1000:.2f}ms였다. 이는 진단용 추가 계측이며 위 성능 표를 대체하지 않는다. 탐색 예산을 깎거나 AI 명령을 지연시켜 전투 결과를 바꾸는 조정은 이번에 넣지 않았다.\n")
lines+=['\n**기존 24척 전장 단독 프로파일**\n','시드 1, 각 목표의 심우주(0)와 소행성 시드 1/2/3. 전투 전체 평균과 난전 p99. 단일 프로파일이므로 전체 최악값이나 승률 표로 해석하지 않는다.\n','| 목표 / 전장 | 평균 µs 전→후 | 난전 p99 ms 전→후 |\n|---|---:|---:|\n']
for x in r['profiles']:
    a,b=x['before'],x['after']
    lines.append(f"| {x['mode']} / {x['field']} | {a['meanMs']*1000:.3f} → {b['meanMs']*1000:.3f} | {fmt(a['brawlP99Ms'])} → {fmt(b['brawlP99Ms'])} |\n")
lines.append('\n기존 문서의 평균 0.2ms/난전 p99 0.6ms 및 환경 난전 p99 1ms 목표는 표에서 초과한 구간을 미달로 유지한다. 대규모 심우주 측정의 개선으로 이 기준을 대체하지 않는다.\n')
lines+=['\n**실제 게임과 검증**\n','기존 24척·소행성 시드 2·×4 자동 관전, 540초 진입 후 40초 실행. 590~615초 보고창의 평균/최소 FPS. 섬멸 시드 1, 점령 시드 5. Debug는 게임/뷰 비최적화·Sim 최적화이고 실제 JIT 설정은 로그에 남겼다. Release는 기존 EXE와 신규 EXE를 연속 비교했다.\n','| 구성 / 목표 | 평균 FPS | 최소 FPS |\n|---|---:|---:|\n']
for mode in ('Annihilation','Domination'):
    for v in ('Debug','Release-before','Release-after'):
        x=r['fps'][f'fps-{v}-{mode}.log'];lines.append(f"| {v} / {mode} | {x['mean']:.1f} | {x['minimum']:.1f} |\n")
lines.append(f"\n- 전체 SimChecks **{r['checks']['final-sim.log']['total']:,}개**, 장면 51개·환경 204개·배포 실행본 **{r['nativeExportChecks']:,}개** 통과. 신규 검사는 동결 원본의 방공/드론 및 센서 순회를 직접 대조한다.\n")
lines.append('- 기존 240전 요약과 함선·어뢰·프로브·환경·사선·엄폐 기록 바이트 일치. 항법 기록은 실제 소요시간 `buildMs`, `planMs`만 제외하고 같다. 환경 1단계 심우주 섬멸/기함 40전도 일치. 규모 시험 전후 요약 해시도 모두 동일.\n')
lines.append('- 입력·밸런스·함선 데이터 변경 없음. FPS 로그 오류/예외 없음. 실제 수동 비행 체감은 미확인.\n')
lines.append('- 실행본: `builds/SpaceFleet-20261012-defense-scaling-Windows-x64/SpaceFleet.exe` 및 같은 이름 ZIP. 독립 .NET 런타임/Sim DLL 포함, ZIP CRC·SHA-256 확인.\n')
lines.append('- [검증·소스/실행기/배포 해시](validation/defense_ai_scaling_20261012/verification.json), [원자료와 측정 스크립트](validation/defense_ai_scaling_20261012/evidence.zip). 개발 중간 시험은 최종 수치에서 제외했다.\n')
doc=Path('docs/BALANCE_perf.md');text=doc.read_text(encoding='utf-8');assert title not in text;doc.write_text(text+''.join(lines),encoding='utf-8')
doc=Path('docs/PLAN.md');text=doc.read_text(encoding='utf-8');assert title not in text
doc.write_text(text+f'''\n\n### {title}

- [x] 진영별 PD/드론 후보 검색, AI 관측 위협 공유, 영향 없는 센서 가림 검사 생략, 정확히 동일한 지형 노출도 표본 공유.
- [x] 동결 방공/센서 회귀검사·기존 240전 상세 기록·규모별 반복 및 소행성/후반전 비교. 60/240Hz·double·관측 원칙·밸런스 유지.
- [x] Debug/배포 실행 검사·FPS·새 EXE/ZIP.
- [ ] 240척 소행성 경로 탐색 집중 구간의 최악 틱, 실제 대규모 렌더/음향/네트워크, 다른 하드웨어와 수동 체감 검증.
- 결과와 증빙: `BALANCE_perf.md`, `validation/defense_ai_scaling_20261012/`. 실행본 `builds/SpaceFleet-20261012-defense-scaling-Windows-x64/SpaceFleet.exe`.
''',encoding='utf-8')
doc=Path('docs/ENVIRONMENT_stage2.md');text=doc.read_text(encoding='utf-8');assert title not in text
doc.write_text(text+f'''\n\n## {title}

방공·AI의 반복 후보 검색과 지형 센서/경로 노출도 계산을 줄였다. 기존 240전의 전투 결과·상세 기록과 대규모 시험 요약은 유지된다. 240척 심우주 및 소행성/후반전, 기존 24척 프로파일·Debug/Release FPS·배포 검사를 추가로 수행했다. 구간별 전후 수치와 미달 기준은 [성능 보고](BALANCE_perf.md)의 같은 날짜 항목, 원자료는 `validation/defense_ai_scaling_20261012/`를 본다. 소행성 대규모 경로 탐색의 순간 최악 지연 및 실제 240척 렌더/멀티플레이 성능은 완료로 처리하지 않는다.
''',encoding='utf-8')
doc=Path('CLAUDE.md');text=doc.read_text(encoding='utf-8')
text=text.replace('SpaceFleet-20261012-projectile-scaling-Windows-x64','SpaceFleet-20261012-defense-scaling-Windows-x64').replace('validation/projectile_scaling_20261012/','validation/defense_ai_scaling_20261012/')
doc.write_text(text,encoding='utf-8')
print('Updated BALANCE_perf, PLAN, ENVIRONMENT_stage2 and latest executable pointer')
