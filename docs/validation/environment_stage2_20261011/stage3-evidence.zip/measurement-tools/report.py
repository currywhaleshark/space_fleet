import csv,hashlib,json,re,statistics,sys,zipfile,subprocess
from pathlib import Path
stage=int(sys.argv[1]); root=Path('shots/environment_stage2');dest=Path('docs/validation/environment_stage2_20261011');dest.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
report={'stage':stage,'baselineCommit':'6629d2e','workorderCommit':'efe46f8','summaryMatches':{},'baselineRunnerSha256':sha(root/'baseline-runner/BattleBatch.dll'),'runnerSha256':sha(root/f'stage{stage}-runner/BattleBatch.dll')}
for mode in ['Annihilation','Flagship','Domination']:
    p=root/f'stage{stage}-{mode}.summaries.json'
    equal=p.read_bytes()==(root/f'baseline-{mode}.summaries.json').read_bytes()
    if mode!='Domination' or stage<=2:assert equal,mode
    report['summaryMatches'][mode]=20 if equal else 0
report['checks']={}
for p in root.glob(f'stage{stage}-*.log'):
    passes=re.findall(r'^PASS: (\d+) (.+)$',p.read_text(encoding='utf-8-sig'),re.M)
    if passes:report['checks'][p.name]=passes
report['profiles']={}
for p in root.glob(f'stage{stage}-profile-*.sections.csv'):
    report['profiles'][p.name]={r['scope']+'/'+r['section']:float(r['usPerTick']) for r in rows(p)}
report['battles']={}
for p in root.glob(f'stage{stage}-*.csv'):
    data=rows(p)
    if not data or 'winner' not in data[0]:continue
    env=rows(p.with_suffix('.environment.csv'))
    report['battles'][p.name]={'count':len(data),'wins':{w:sum(x['winner']==w for x in data) for w in ['Blue','Red','Draw','Unresolved']},
        'collisions':sum(int(x['shipCollisions']) for x in env),'collisionDamage':sum(float(x['collisionModuleDamage']) for x in env),'stuck':sum(int(x['stuckDetections']) for x in env),
        'blocked':{w:sum(int(x['blocked'+w]) for x in env) for w in ['Rails','Missiles','Torpedoes','Probes']}}
    nav=p.with_suffix('.navigation.csv')
    if nav.exists():
        ns=rows(nav);report['battles'][p.name]['navigation']={k:sum(float(x[k]) for x in ns) for k in ns[0] if k not in ['seed','mirror','fieldSeed']}
sources=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines()
report['sourceSha256']={p:sha(Path(p)) for p in sorted(sources) if p.startswith(('src/','tests/','tools/')) and Path(p).is_file()}
with zipfile.ZipFile(dest/f'stage{stage}-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.glob(f'stage{stage}-*')):
        if p.is_file():z.write(p,p.name)
    for p in root.glob('baseline-*.summaries.json'):z.write(p,'baseline/'+p.name)
    for name in ['verify-stage.ps1','report.py']:z.write(root/name,'measurement-tools/'+name)
report['evidenceSha256']=sha(dest/f'stage{stage}-evidence.zip')
(dest/f'stage{stage}.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k in ['summaryMatches','profiles','battles']},indent=2,ensure_ascii=False))
