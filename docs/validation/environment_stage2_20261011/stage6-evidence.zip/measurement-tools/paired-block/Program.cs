using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
using var process=Process.GetCurrentProcess();
long available=process.ProcessorAffinity.ToInt64(), chosen=(available & 4)!=0 ? 4 : available & -available;
process.ProcessorAffinity=(nint)chosen;
string root=Path.GetFullPath(args[0]), stage=args[1];
var baseline=new Runner(Path.Combine(root,"baseline-runner"));
var current=new Runner(Path.Combine(root,stage+"-runner"));
const int ticks=44856, block=120;
Console.WriteLine($"Affinity {chosen}; interleaved {block}-tick blocks; one paired warmup then five paired battles.");
var rows=new List<object>(); string? reference=null;
for(int repeat=0;repeat<=5;repeat++)
{
    var a=baseline.Create(); var b=current.Create(); long ta=0,tb=0;
    GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
    for(int i=0;i<ticks;i+=block)
    {
        int count=Math.Min(block,ticks-i);
        if((i/block+repeat)%2==0) { ta+=Advance(a.Step,count); tb+=Advance(b.Step,count); }
        else { tb+=Advance(b.Step,count); ta+=Advance(a.Step,count); }
    }
    string sa=a.Summary(),sb=b.Summary(); reference??=sa;
    if(sa!=reference || sb!=reference)throw new Exception("Summary mismatch");
    double baselineUs=ta*1e6/Stopwatch.Frequency/ticks, currentUs=tb*1e6/Stopwatch.Frequency/ticks;
    Console.WriteLine($"{repeat}: baseline {baselineUs:F3}, {stage} {currentUs:F3} us/tick ({100*(currentUs/baselineUs-1):F3}%)");
    if(repeat>0)rows.Add(new{repeat,baselineUs,currentUs,deltaPercent=100*(currentUs/baselineUs-1)});
}
File.WriteAllText(Path.Combine(root,stage+"-inprocess-block.json"),JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));
static long Advance(Action step,int count) { long start=Stopwatch.GetTimestamp();for(int j=0;j<count;j++)step();return Stopwatch.GetTimestamp()-start; }
sealed class Runner
{
    readonly Assembly assembly;readonly Type worldType,configType;
    public Runner(string path)
    {
        assembly=new Context(path).LoadFromAssemblyPath(Path.Combine(path,"BattleBatch.dll"));
        worldType=assembly.GetType("SpaceFleet.Sim.SimWorld")!;configType=assembly.GetType("SpaceFleet.Sim.BattleConfig")!;
    }
    public State Create()
    {
        object world=Activator.CreateInstance(worldType)!,config=Activator.CreateInstance(configType)!;
        configType.GetProperty("Seed")!.SetValue(config,1);
        assembly.GetType("SpaceFleet.Sim.BattleSetup")!.GetMethod("Spawn")!.Invoke(null,new[]{world,config});
        var step=(Action)worldType.GetMethod("Step")!.CreateDelegate(typeof(Action),world);
        object log=worldType.GetProperty("Log")!.GetValue(world)!;
        return new(step,()=>{log.GetType().GetMethod("Finish")!.Invoke(log,null);return(string)log.GetType().GetMethod("Summary")!.Invoke(log,null)!;});
    }
    public record State(Action Step,Func<string> Summary);
    sealed class Context(string path):AssemblyLoadContext
    {
        protected override Assembly? Load(AssemblyName name)
        {string file=Path.Combine(path,name.Name+".dll");return File.Exists(file)?LoadFromAssemblyPath(file):null;}
    }
}

