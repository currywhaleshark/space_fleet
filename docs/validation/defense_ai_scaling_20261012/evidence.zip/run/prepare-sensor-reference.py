from pathlib import Path
s=Path('shots/defense_ai_scaling_20261012/baseline-source/SensorNet.cs').read_text(encoding='utf-8')
s=s[s.index('    public void Update('):s.index('    public static TrackLevel Classify(')]
s=s.replace('public void Update(', 'internal void ReferenceUpdate(')
Path('tests/SimChecks/SensorTraversalReference.cs').write_text('''// Frozen 36a7254 full ship-observer traversal for occlusion regression checks.
using System;
using System.Collections.Generic;
using Godot;
namespace SpaceFleet.Sim;
public sealed partial class SensorNet
{
'''+s+'}\n',encoding='utf-8')
