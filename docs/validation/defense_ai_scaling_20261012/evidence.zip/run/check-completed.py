from pathlib import Path
import json,csv
p=Path('shots/defense_ai_scaling_20261012');old=Path('shots/projectile_scaling_20261012')
def rows(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return [{k:v for k,v in r.items() if k not in ('buildMs','planMs')} for r in csv.DictReader(f)]
done=[]
for log in sorted(p.glob('final-*-field*.log')):
    if 'PASS: 20/20 battle summaries match' not in log.read_text(encoding='utf-8-sig'):continue
    label=log.stem
    for suffix in ('summaries.json','ships.csv','am.csv','probes.csv','environment.csv','environment-events.csv','sight.csv','cover.csv','navigation.csv'):
        a,b=old/(label+'.'+suffix),p/(label+'.'+suffix)
        assert (rows(a)==rows(b) if suffix=='navigation.csv' else a.read_bytes()==b.read_bytes()),(label,suffix)
    done.append(label)
p.joinpath('partial-matrix.json').write_text(json.dumps(done,indent=2),encoding='utf-8')
print(f'All detailed records match for {len(done)*20}/240 completed battles')
print('\n'.join(done[-3:]))
