from pathlib import Path
import csv,json,re,statistics
root=Path('shots/environment_stage2')
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
profiles=[]
for mode in ['Annihilation','Flagship','Domination']:
 for seed in [1,2,3]:
  prefix=f'stage6-profile-AsteroidCluster-{mode}-pair{seed}'
  p=root/(prefix+'.sections.csv')
  if not p.exists():continue
  a={r['section']:float(r['usPerTick']) for r in rows(p) if r['scope']=='All'}
  b={r['section']:float(r['usPerTick']) for r in rows(root/f'stage6-profile-DeepSpace-{mode}-pair{seed}.sections.csv') if r['scope']=='All'}
  ticks=rows(root/(prefix+'.ticks.csv'));brawl=next(r for r in ticks if r['scope']=='Brawl')
  profiles.append(dict(mode=mode,fieldSeed=seed,deep=b,asteroids=a,ratio=a['Tick']/b['Tick'],brawlP99=float(brawl['p99Ms']) if brawl['p99Ms'] else None))
report={'profilePairs':profiles,'emptyPaired':None,'fps':{},'releaseFps':{}}
p=root/'stage6-inprocess-block.json'
if p.exists():
 pairs=json.loads(p.read_text());a=statistics.median(x['baselineUs'] for x in pairs);b=statistics.median(x['currentUs'] for x in pairs)
 report['emptyPaired']={'trials':pairs,'baselineMedian':a,'currentMedian':b,'deltaPercent':100*(b/a-1)}
for kind,prefix in [('fps','stage6-fps'),('releaseFps','stage6-release-fps')]:
 for mode in ['Annihilation','Domination']:
  p=root/f'{prefix}-{mode}.log'
  if not p.exists():continue
  s=p.read_text(encoding='utf-8-sig');samples=[(int(t),float(f)) for t,f in re.findall(r'perf t=(\d+)s fps=([\d.]+)',s)]
  window=[f for t,f in samples if 590<=t<=615]
  report[kind][mode]={'samples':samples,'window590to615':window,'minimum':min(window) if window else None,'mean':statistics.mean(window) if window else None,'tenMinute':re.findall(r'autoplay 10min:.*',s),'errors':len(re.findall(r'ERROR:|Exception',s))}
(root/'stage6-performance-analysis.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
