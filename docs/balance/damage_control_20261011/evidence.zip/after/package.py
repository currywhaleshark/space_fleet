"""Run from the repository root after the eight named batch runs have completed."""
import collections
import csv
import hashlib
import io
import json
import pathlib
import statistics
import zipfile

root = pathlib.Path('shots/damage-control-20261011')
before = pathlib.Path('shots/balance-review-20261010/baseline')
output = pathlib.Path('docs/balance/damage_control_20261011')
output.mkdir(parents=True, exist_ok=True)
groups = {
    'symmetric_fleet': ['Earth-Earth', 'Mars-Mars'],
    'mixed_fleet': ['Earth-Mars', 'Mars-Earth'],
    'duel_20km': ['duel-Battleship-20000-Earth-Mars', 'duel-Battleship-20000-Mars-Earth'],
    'duel_130km': ['duel-Battleship-130000-Earth-Mars', 'duel-Battleship-130000-Mars-Earth'],
}
def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return [r for r in csv.DictReader(stream) if int(r['seed']) in (1, 2)]

analysis = {}
for group, names in groups.items():
    analysis[group] = {}
    for label, source in [('before', before), ('after', root)]:
        winners = collections.Counter()
        side_winners = collections.Counter()
        times = []
        bb = {}
        for name in names:
            battle = rows(source / (name + '.csv'))
            assert {(r['seed'], r['mirror']) for r in battle} == {('1','0'),('1','1'),('2','0'),('2','1')}
            blue, red = name.split('-')[-2:]
            for r in battle:
                winner = r['winner']
                side_winners[name + '/' + winner] += 1
                winners[blue if winner == 'Blue' else red if winner == 'Red' else winner] += 1
                times.append(float(r['outcomeTime']))
            for s in rows(source / (name + '.ships.csv')):
                if s['kind'] != 'Battleship': continue
                stats = bb.setdefault(s['design'], {'ships':0, 'shots':0, 'zero_shots':0})
                stats['ships'] += 1
                stats['shots'] += int(s['rails'])
                stats['zero_shots'] += int(s['rails']) == 0
        analysis[group][label] = dict(winners=winners, side_winners=side_winners,
            median_seconds=statistics.median(times), battleships=bb, runs=len(times))
sampled_repairs = {}
for name in sum(groups.values(), []):
    for r in rows(root / (name + '.telemetry.csv')):
        key = (name, r['seed'], r['mirror'], r['callsign'])
        sampled_repairs[key] = max(sampled_repairs.get(key, 0), int(r['repairs']))
analysis['sampled_repairs'] = {'minimum_completions':sum(sampled_repairs.values()),
    'ships_with_completion':sum(n > 0 for n in sampled_repairs.values()),
    'note':'5-second telemetry may miss completions immediately before the final outcome.'}
(output / 'analysis.json').write_text(json.dumps(analysis, indent=2), encoding='utf-8')

evidence = {}
def add(archive, name, data):
    archive.writestr(name, data)
    evidence[name] = hashlib.sha256(data).hexdigest()

with zipfile.ZipFile(output / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.iterdir()):
        if path.suffix not in ('.csv','.json','.log','.py'): continue
        add(archive, 'after/' + path.name, path.read_bytes())
    for name in sum(groups.values(), []):
        for suffix in ('.csv', '.ships.csv', '.am.csv'):
            path = before / (name + suffix)
            with path.open(encoding='utf-8-sig', newline='') as stream:
                reader = csv.DictReader(stream); fields = reader.fieldnames
                selected = [r for r in reader if int(r['seed']) in (1, 2)]
            text = io.StringIO(newline=''); writer = csv.DictWriter(text, fieldnames=fields)
            writer.writeheader(); writer.writerows(selected)
            add(archive, 'before/' + path.name, text.getvalue().encode('utf-8'))
    for name in ['damage-control-simchecks.log', 'damage-control-gamechecks-native.log',
                 'damage-control-weapon-input-test.log', 'damage-control-flow-test.log',
                 'damage-control-hud.png', 'damage-control-radial.png']:
        path = pathlib.Path('shots') / name
        add(archive, 'checks/' + name, path.read_bytes())
sources = sorted(set(pathlib.Path('src/Sim').glob('*.cs')) | set(pathlib.Path('data/ships').glob('*.json'))
    | set(pathlib.Path('src/Game').glob('*.cs')) | set(pathlib.Path('tools/BattleBatch').glob('*.cs'))
    | set(pathlib.Path('tests/SimChecks').glob('*.cs')))
manifest = {'baseline_commit':'4ac58b7406d415db3a9d4054bbf777e21e0fd16c', 'runs':32,
    'seeds':[1,2], 'mirrored':True, 'minutes':25, 'groups':groups,
    'command':'dotnet tools/BattleBatch/bin/Release/net8.0/BattleBatch.dll --seeds 1,2 --mirror --jobs 2 --minutes 25 --blue-design <Earth|Mars> --red-design <Earth|Mars> --telemetry --output <path> [--duel Battleship --distance <20000|130000>]',
    'before_source':'docs/balance/review_20261010/evidence.zip; before CSVs filtered to seeds 1,2',
    'source_sha256':{str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
    'evidence_sha256':evidence, 'archive_sha256':hashlib.sha256((output/'evidence.zip').read_bytes()).hexdigest()}
(output/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
with zipfile.ZipFile(output/'evidence.zip') as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == value for name, value in evidence.items())
print('Packaged 32 matched battles;', len(evidence), 'verified files;', (output/'evidence.zip').stat().st_size, 'bytes')
