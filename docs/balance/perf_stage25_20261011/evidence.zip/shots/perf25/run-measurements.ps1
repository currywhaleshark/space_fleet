$ErrorActionPreference = 'Stop'
. ./tools/godot.ps1
while (!(Test-Path -LiteralPath 'shots/perf25/before-ann-20.summaries.json') -or !(Test-Path -LiteralPath 'shots/perf25/after-ann-20.summaries.json')) { Start-Sleep -Seconds 5 }
Write-Output 'Correctness batches complete; beginning serial performance measurements.'
foreach ($sfPhase in @('before','after')) {
    $sfBatchDll = if ($sfPhase -eq 'before') { 'shots/perf25/before-bin/BattleBatch.dll' } else { 'tools/BattleBatch/bin/Release/net8.0/BattleBatch.dll' }
    dotnet $sfBatchDll --seeds 1 --objective Domination --profile --output "shots/perf25/$sfPhase-dom-final.csv" > "shots/perf25/$sfPhase-dom-final.log" 2>&1
    if ($LASTEXITCODE -ne 0) { throw "$sfPhase final profile failed" }
    Write-Output "$sfPhase Release batch profile complete."
}
function Invoke-PerfGame([string]$Exe,[string]$Label,[bool]$Project) {
    $sfLog = Join-Path $ProjectDir "shots/perf25/$Label.log"
    $sfArgs = @('--log-file',('"'+$sfLog+'"'))
    if ($Project) { $sfArgs += @('--path',('"'+$ProjectDir+'"')) }
    $sfArgs += @('--','--autoplay','--seed=1','--blue-design=Earth','--red-design=Earth','--objective=Domination','--advance=540','--perf-trace','--perf-seconds=40')
    $sfProcess = Start-Process -FilePath $Exe -WorkingDirectory (Split-Path -Parent $Exe) -ArgumentList $sfArgs -WindowStyle Hidden -PassThru
    if (!$sfProcess.WaitForExit(900000)) { Stop-Process -Id $sfProcess.Id; throw "$Label timed out" }
    $sfText = Get-Content -LiteralPath $sfLog -Encoding UTF8 -Raw
    if ($sfProcess.ExitCode -ne 0 -or $sfText -notmatch 'sim-profile') { throw "$Label failed: exit=$($sfProcess.ExitCode)" }
    Write-Output "$Label complete; exit=$($sfProcess.ExitCode)"
}
Invoke-PerfGame (Join-Path $ProjectDir 'shots/perf25/before-release-game/SpaceFleet.exe') 'before-release-game' $false
Invoke-PerfGame (Join-Path $ProjectDir 'builds/SpaceFleet-20261011-wreck-collision-Windows-x64/SpaceFleet.exe') 'after-release-game' $false
Invoke-PerfGame $Godot 'after-debug-game' $true
Write-Output 'All serial performance measurements complete.'
