using System.Globalization;
using System.Text.Json;
using Godot;
using SpaceFleet.Sim;
CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;
var expected=JsonSerializer.Deserialize<List<Ref>>(File.ReadAllText("shots/balance-review-20261010/baseline/duel-Escort-45000-Earth-Earth.summaries.json"))!;
var output=new List<string>{"swapLabels,reverseAdd,seed,mirror,winner,time,blueRails,redRails"};
int verified=0;
foreach(bool swap in new[]{false,true}) foreach(bool reverse in new[]{false,true})
foreach(int seed in Enumerable.Range(1,8)) foreach(bool mirror in new[]{false,true}) {
 var world=new SimWorld();
 var blue=new ShipBody(swap?"DUEL-R":"DUEL-B",ShipDefinitions.For(HullKind.Escort),Faction.Blue);
 var red=new ShipBody(swap?"DUEL-B":"DUEL-R",ShipDefinitions.For(HullKind.Escort),Faction.Red);
 if(reverse){world.Add(red);world.Add(blue);}else{world.Add(blue);world.Add(red);}
 var random=new Random(seed);
 foreach(var ship in new[]{blue,red}) {
  bool front=(ship.Faction==Faction.Blue)!=mirror;
  ship.Place(new Vec3d(0,(random.NextDouble()-.5)*2000,front?0:-45000),new Quaternion(Vector3.Up,front?0:Mathf.Pi));
  world.AttachBrain(ship,ShipOrder.AttackOn(ship==blue?red:blue));
 }
 world.Doctrine=new FleetDoctrine();world.Sensors.Update(world.Ships,0,force:true);
 world.Rules=new BattleRules(world);world.Log=new BattleLog(world);
 while(world.Time<1500&&world.Rules.Outcome is null)world.Step();
 world.Log.Finish();
 if(!swap&&!reverse){if(world.Log.Summary()!=expected.Single(x=>x.Seed==seed&&x.Mirror==mirror).Summary)throw new Exception("Reference mismatch");verified++;}
 output.Add($"{swap},{reverse},{seed},{mirror},{world.Rules.Outcome?.Winner?.ToString()??"Draw"},{world.Time:F3},{world.Log.Ship(blue).Rails},{world.Log.Ship(red).Rails}");
}
File.WriteAllLines("shots/balance-review-20261010/identity-probe.csv",output);
Console.WriteLine($"PASS reference {verified}/16; sensitivity experiments {output.Count-1}");
sealed record Ref(int Seed,bool Mirror,string Summary);
