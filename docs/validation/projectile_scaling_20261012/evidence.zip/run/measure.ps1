$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/projectile_scaling_20261012'
$old=Join-Path (Get-Location).Path 'shots/environment_stage2_optimization/runner/BattleBatch.dll'
foreach($repeat in @(1,2,3)) {
 foreach($groups in @(1,2,4,10)) {
  $variants=if($repeat%2 -eq 1){@('before','after')}else{@('after','before')}
  foreach($variant in $variants) {
   $label='scale-'+$groups+'-'+$repeat+'-'+$variant
   & dotnet (Join-Path $root ('scale-'+$variant+'/ScaleBench.dll')) --groups $groups --repeats 1 --output (Join-Path $root ($label+'.json')) *> (Join-Path $root ($label+'.log'))
   if($LASTEXITCODE -ne 0){throw $label}
   Get-Content (Join-Path $root ($label+'.log')) -Tail 1 -Encoding UTF8
  }
 }
}
foreach($mode in @('Annihilation','Flagship','Domination')) {
 foreach($field in @(0,1,2,3)) {
  foreach($variant in @('before','after')) {
   $runner=if($variant -eq 'before'){$old}else{Join-Path $root 'runner/BattleBatch.dll'}
   $battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
   $label='profile-'+$mode+'-field'+$field+'-'+$variant
   & dotnet $runner --seeds 1 --objective $mode --battlefield $battlefield --field-seed ([Math]::Max(1,$field)) --profile --output (Join-Path $root ($label+'.csv')) *> (Join-Path $root ($label+'.log'))
   if($LASTEXITCODE -ne 0){throw $label}
   Write-Output ('Measured '+$label)
  }
 }
}
New-Item -ItemType File -Force (Join-Path $root 'measurement-done') | Out-Null
