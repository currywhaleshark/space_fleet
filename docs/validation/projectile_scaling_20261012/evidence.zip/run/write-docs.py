from pathlib import Path
import json,statistics,re
root=Path('shots/projectile_scaling_20261012')
v=json.loads(Path('docs/validation/projectile_scaling_20261012/verification.json').read_text(encoding='utf-8'))
heading='### 2026-10-12 — 탄체 후보 검사·함대 규모 부하 시험'
lines=[heading,'',
'기준은 `d15d525`. 탄체마다 모든 함선·미사일·프로브·방어드론 모함을 순회하던 부분을 줄였다. 무장/센서/AI/편성 데이터, 60Hz 월드와 240Hz 연속 충돌은 유지한다.', '',
'- `SweepIndex`: 이동 AABB를 가장 넓은 축으로 정렬하고 누적 상한으로 먼 후보를 제외한다. 후보 개수 제한이나 좌표 양자화 없이 원래 순서로 정밀 판정을 수행한다. 배열을 재사용한다.',
'- 함선 수 48 이상·탄체 8 이상에서 함체와 드론 모함 인덱스를 사용한다. 미사일/프로브는 표적 8개 이상·표적×탄체 128 이상일 때 사용한다. 작은 목록은 기존 순회로 남겨 준비 비용을 피한다.',
'- 함체/실드 반경은 하위 틱마다 읽고, 명중으로 값이 바뀌면 즉시 갱신한다. 삭제된 미사일·프로브의 참조 순서는 보존하되 현재 생존 상태를 확인한다. 표적 지정 근접신관, 부분 수명, 프로브 60Hz 위치 보간을 유지한다.',
'- 소형 표적의 좌표가 ±1e15m를 넘거나 하위 틱 이동이 축당 1e6m를 넘는 경우 기존 전수 검사를 사용한다. 일반 구간은 좌표 반올림 여유를 포함한 경계를 사용한다. 긴 경로의 기존 이차식이 수치 오차로 접선을 명중 처리하는 경우도 보존한다.',
'- `tools/ScaleBench`는 같은 월드에 기존 12척 편성을 진영별 1·2·4·10개 배치한다. 게임 출격 수는 바꾸지 않는다. 자세한 조건과 재현은 [시험 설명](../tools/ScaleBench/README.md).','',
'**확장 부하 — 세 번 측정의 중앙값**','',
'Earth/Earth 심우주, 시작 거리 40km, 준비 15초 후 60초 측정. 원본/수정본 실행 순서를 교대하고 다른 게임·빌드·검사와 겹치지 않았다. 숫자는 시뮬레이션 틱이며 FPS가 아니다. 240척은 플레이어당 현행 12척 편성이 따라오는 10:10을 가정한 합성 부하다. 실제 편대 수가 확정된 것은 아니다.','',
'| 총 함선 | 동시 탄체/미사일 최고 | 평균 틱 ms 전→후 | p99 ms 전→후 | 평균 감소 |',
'|---:|---:|---:|---:|---:|']
for r in v['scale']:
    a,b=r['before'],r['after']
    lines.append(f"| {r['ships']} | {b['peakRails']:.0f}/{b['peakMissiles']:.0f} | {a['meanMs']:.3f} → {b['meanMs']:.3f} | {a['p99Ms']:.3f} → {b['p99Ms']:.3f} | {(1-b['meanMs']/a['meanMs'])*100:.1f}% |")
large=v['scale'][-1]
sections=sorted(((k,x) for k,x in large['after']['sectionsUs'].items() if k in ('AI','ShipStep','Collision','Projectiles','Missiles','PointDefense','Drones','Sensors','Probes','Post')),key=lambda x:-x[1])
lines+=['',f"240척 잔여 비용(평균): "+', '.join(f'{k} {x/1000:.3f}ms' for k,x in sections[:5])+'.',
'60Hz 전체 틱 예산은 16.67ms다. 평균이 개선되어도 240척 혼잡 구간 p99가 예산을 넘으면 확장 완료로 보지 않는다. GPU·음향·네트워크 비용도 별도이며, 소행성·장시간 잔해전에서의 240척과 수동 조작감은 미확인이다. 다음 우선순위는 대규모 전장의 PD 표적 선택/사선 검사와 AI 교전 비용이다.','',
'**기존 24척 전장 — Release 단독 시드 1**','',
'| 목표 / 지형 시드(0=심우주) | 평균 µs/틱 전→후 | 난전 p99 ms 전→후 |',
'|---|---:|---:|']
for r in v['profiles']:
    a,b=r['before'],r['after'];fmt=lambda x:'—' if x is None else f'{x:.4f}'
    lines.append(f"| {r['mode']} / {r['field']} | {a['meanMs']*1000:.3f} → {b['meanMs']*1000:.3f} | {fmt(a['brawlP99Ms'])} → {fmt(b['brawlP99Ms'])} |")
a=statistics.median(x['baselineUs'] for x in v['pairedBlock']);b=statistics.median(x['currentUs'] for x in v['pairedBlock'])
lines+=['',f'심우주 섬멸전은 CPU affinity 4, 120틱 교차, 준비 1쌍+측정 5쌍으로 추가 대조했다. 기준 {a:.3f} → 수정 {b:.3f}µs/틱, 중앙값 비 {(b/a-1)*100:+.2f}%. 각 쌍의 전투 요약도 동일하다.',
'소행성 난전 p99 1ms 및 기존 프로젝트 전체 0.2ms 평균/0.6ms p99 목표가 위 표에서 넘는 구간은 미달로 남긴다. 한 시드의 성능 표를 모든 전투의 최악값으로 해석하지 않는다.','',
'**실제 게임·검증**','',
'실제 게임은 기존 24척, 렌더링·음향 ON, ×4 자동 관전, 540초 진입 후 실시간 40초. 590~615초 보고창의 평균/최소 FPS다. Debug의 시뮬레이션은 이전 커밋처럼 별도 최적화 어셈블리이며 게임/뷰 Debug 설정은 유지한다.','',
'| 구성 / 목표 | 평균 FPS | 최소 FPS |','|---|---:|---:|']
for name,r in v['fps'].items():lines.append(f"| {name.removeprefix('fps-').removesuffix('.log')} | {r['mean']:.1f} | {r['minimum']:.1f} |")
checks=v['checks']['final-sim.log']['total']
lines+=['',
f'- 전체 시뮬레이션 **{checks:,}개** 통과. 신규 검사는 동결된 기존 탄체 순회와 이동/신관/부분 수명/삭제/실드 및 같은 틱 격침/드론/큰 좌표/리셋을 직접 대조한다.',
f"- 기존 **{v['summaryMatches']}전 요약과 함선·어뢰·프로브·환경·엄폐·사선 CSV 바이트 일치**. 항법은 시간 계측 `buildMs`, `planMs`만 제외하고 동일. 환경 1단계 심우주 섬멸/기함 40전도 직접 바이트 대조했다.",
'- 확장 24·48·96·240척 전후 세 반복의 전투 요약 SHA-256도 모두 일치한다. 변경된 기본 편성이나 밸런스 데이터는 없다.',
f"- Debug 장면 흐름 {v['checks']['native-flow-test.log']['total']}개, 환경 {v['checks']['native-environment-test.log']['total']}개, 내보낸 실행본 **{v['nativeExportChecks']:,}개** 통과. FPS 로그 오류·예외 0회. 수동 플레이 체감은 미확인.",
'- 실행본: `builds/SpaceFleet-20261012-projectile-scaling-Windows-x64/SpaceFleet.exe` 및 같은 이름 ZIP. 독립 .NET 런타임/Sim DLL, ZIP CRC와 SHA-256 확인.',
'- [검사·소스/실행기/배포본 해시](validation/projectile_scaling_20261012/verification.json), [원자료·측정/검증 스크립트](validation/projectile_scaling_20261012/evidence.zip). 초기 측정은 드론 모함 병목을 찾기 위한 참고 자료로 분리했으며 위 표에는 최종 측정만 사용한다.','']
def append(path,text):
    p=Path(path);s=p.read_text(encoding='utf-8-sig');assert heading not in s,path;p.write_text(s.rstrip()+'\n\n'+text+'\n',encoding='utf-8')
append('docs/BALANCE_perf.md','\n'.join(lines))
append('docs/ENVIRONMENT_stage2.md',heading+'\n\n탄체 및 소형 표적/드론 모함의 공간 후보 검사를 추가하고 24~240척 부하 시험을 수행했다. 기존 240전 결과와 환경 1단계 심우주 40전을 보존했다. 최종 구간별 성능, 남은 p99 미달 및 확장 한계는 [성능 보고](BALANCE_perf.md)에 기록했다. 240척은 합성 심우주 부하이며 실제 10:10 멀티플레이/렌더 성능 검증은 아니다.')
append('docs/PLAN.md',heading+'\n\n- [x] 탄체의 소형 표적·함체·드론 모함 후보 검색과 하위 틱 반경 갱신. 240Hz/double/명중 순서 유지.\n- [x] 동결 원본 회귀검사, 기존 240전/단계1 심우주40전 일치, 24·48·96·240척 전후 세 반복.\n- [x] 장면/환경/배포 검사, Debug/Release ×4 FPS, 실행본 갱신.\n- [ ] 240척 혼잡 구간의 60Hz 여유: PD·AI 교전 및 사선 비용 추가 최적화. 실제 네트워크·렌더·대규모 소행성/장기 잔해전 검증.\n- 보고와 증빙: `BALANCE_perf.md`, `validation/projectile_scaling_20261012/`. 실행본 `builds/SpaceFleet-20261012-projectile-scaling-Windows-x64/SpaceFleet.exe`.')
p=Path('CLAUDE.md');s=p.read_text(encoding='utf-8-sig')
s=re.sub(r'^- 실행본:.*$',f'- 실행본: `builds/SpaceFleet-20261012-projectile-scaling-Windows-x64/SpaceFleet.exe`와 같은 이름의 ZIP. 독립 .NET 런타임 및 `SpaceFleet.Sim.dll` 포함. 배포 EXE {v["nativeExportChecks"]:,}개 검사 통과. 240전 대조·규모별 부하·FPS·해시는 `docs/validation/projectile_scaling_20261012/verification.json`과 `evidence.zip`; 성능 해석은 `docs/BALANCE_perf.md`.',s,flags=re.M)
p.write_text(s,encoding='utf-8')
