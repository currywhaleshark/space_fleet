$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/environment_stage2_optimization'
$runner=Join-Path $root 'runner/BattleBatch.dll'
foreach ($mode in @('Annihilation','Flagship','Domination')) {
  foreach ($field in @(0,1,2,3)) {
    $prefix=if($field -eq 0){'stage6-'+$mode}else{'stage6-asteroid-'+$mode+'-field'+$field}
    $label='final-'+$mode+'-field'+$field
    $battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
    $fieldSeed=if($field -eq 0){1}else{$field}
    & dotnet $runner --seeds 1,2,3,4,5,6,7,8,9,10 --mirror --jobs 6 --objective $mode --battlefield $battlefield --field-seed $fieldSeed --compare-summaries (Join-Path (Get-Location).Path ('shots/environment_stage2/'+$prefix+'.summaries.json')) --output (Join-Path $root ($label+'.csv')) *> (Join-Path $root ($label+'.log'))
    if($LASTEXITCODE -ne 0){throw ('Matrix failed: '+$label)}
    Write-Output ('PASS: '+$label+' 20 summaries identical')
  }
}
New-Item -ItemType File -Force (Join-Path $root 'matrix-done') | Out-Null
