$ErrorActionPreference='Stop'
. ./tools/godot.ps1
$root=Join-Path $ProjectDir 'shots/navigation_scaling_20261012'
$old=Join-Path $root 'baseline-source'
dotnet build tools/ScaleBench/ScaleBench.csproj -c Release -p:SimSource="$old" -o (Join-Path $root 'before-runner') *> (Join-Path $root 'before-build.log')
if($LASTEXITCODE -ne 0){throw 'Before build'}
dotnet build tools/ScaleBench/ScaleBench.csproj -c Release -o (Join-Path $root 'after-runner') *> (Join-Path $root 'after-build.log')
if($LASTEXITCODE -ne 0){throw 'After build'}
foreach($repeat in 1,2,3){
 $variants=if($repeat%2){@('before','after')}else{@('after','before')}
 foreach($variant in $variants){
  dotnet (Join-Path $root "$variant-runner/ScaleBench.dll") --groups 10 --repeats 1 --battlefield AsteroidCluster --field-seed 2 --output (Join-Path $root "asteroid-$repeat-$variant.json") *> (Join-Path $root "asteroid-$repeat-$variant.log")
  if($LASTEXITCODE -ne 0){throw "$repeat $variant"}
  Get-Content -Encoding UTF8 (Join-Path $root "asteroid-$repeat-$variant.log") -Tail 1
 }
}
dotnet build tests/SimChecks/SimChecks.csproj -c Release -o (Join-Path $root 'check-runner') *> (Join-Path $root 'check-build.log')
if($LASTEXITCODE -ne 0){throw 'Check build'}
dotnet (Join-Path $root 'check-runner/SimChecks.dll') *> (Join-Path $root 'exact-sim.log')
if($LASTEXITCODE -ne 0){throw 'Sim checks'}
Write-Output 'Full SimChecks passed'
