$ErrorActionPreference='Stop'
$optRoot=Join-Path (Get-Location).Path 'shots/environment_stage2_optimization'
while(-not (Test-Path -LiteralPath (Join-Path $optRoot 'matrix-done'))){Start-Sleep -Seconds 10}
. ./tools/godot.ps1
$Name='SpaceFleet-20261012-environment-stage2-optimized-Windows-x64'
$sfRoot=Join-Path $ProjectDir 'builds'
$sfOutput=Join-Path $sfRoot $Name
$sfExe=Join-Path $sfOutput 'SpaceFleet.exe'
$sfLogs=Join-Path $ProjectDir ('shots/'+$Name)
if(!(Test-Path -LiteralPath $sfExe)){throw 'Missing exported executable'}
# The first concurrent export check timed out before the engine wrote its first
# log line. Retain that attempt and rerun every check in isolation on the SAME
# executable, allowing 120 seconds for process startup. No test is skipped.
$firstAttempt=Join-Path $sfLogs 'combat-visual-test.log'
if(Test-Path -LiteralPath $firstAttempt){Copy-Item -LiteralPath $firstAttempt -Destination (Join-Path $optRoot 'export-first-combat-visual-timeout.log')}
$source=Get-Content -LiteralPath (Join-Path $ProjectDir 'tools/export-windows.ps1') -Raw -Encoding UTF8
$offset=$source.IndexOf('$sfChecks = @()')
if($offset -lt 0){throw 'Export verification block not found'}
$tail=$source.Substring($offset).Replace('WaitForExit(45000)','WaitForExit(120000)')
$tail | Set-Content -LiteralPath (Join-Path $optRoot 'export-verification-used.ps1') -Encoding UTF8
& ([scriptblock]::Create($tail)) *> (Join-Path $optRoot 'final-export-retry.log')
Get-Content (Join-Path $optRoot 'final-export-retry.log') -Tail 15 -Encoding UTF8
foreach($case in @(@{Mode='Annihilation';Seed=1},@{Mode='Domination';Seed=5})) {
 $trace=Join-Path $optRoot ('final-release-'+$case.Mode+'.log')
 $arguments=@('--log-file',('"'+$trace+'"'),'--','--autoplay','--autoplay-speed=4',('--seed='+$case.Seed),'--blue-design=Earth','--red-design=Earth',('--objective='+$case.Mode),'--battlefield=AsteroidCluster','--field-seed=2','--advance=540','--perf-trace','--perf-seconds=40','--perf-no-sim-profile')
 $gameProcess=Start-Process -FilePath $sfExe -ArgumentList $arguments -WorkingDirectory $sfOutput -WindowStyle Hidden -PassThru
 if(-not $gameProcess.WaitForExit(300000)){Stop-Process -Id $gameProcess.Id -Force;throw 'Our Release FPS run timed out'}
 if($gameProcess.ExitCode -ne 0){throw ('FPS failed '+$gameProcess.ExitCode)}
 Write-Output ('Measured final Release FPS: '+$case.Mode)
}
New-Item -ItemType File -Force (Join-Path $optRoot 'native-done') | Out-Null
