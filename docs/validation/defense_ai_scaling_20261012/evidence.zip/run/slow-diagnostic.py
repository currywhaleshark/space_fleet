from pathlib import Path
p=Path('shots/defense_ai_scaling_20261012/slow-detail');p.mkdir(exist_ok=True)
p.joinpath('slow.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings></PropertyGroup><ItemGroup><Reference Include="GodotSharp"><HintPath>../../../.godot/mono/temp/bin/Debug/GodotSharp.dll</HintPath></Reference><Compile Include="../../../src/Sim/*.cs" Exclude="../../../src/Sim/SimProfiler.cs;../../../src/Sim/SimTerrainNavigation.cs"/><EmbeddedResource Include="../../../data/ships/*.json" LogicalName="SpaceFleet.data.ships.%(Filename)%(Extension)"/></ItemGroup></Project>''',encoding='utf-8')
s=Path('src/Sim/SimProfiler.cs').read_text(encoding='utf-8').replace('TerrainCollision, Post,','TerrainCollision, NavigationPlan, Post,')
p.joinpath('SimProfiler.cs').write_text(s,encoding='utf-8')
s=Path('src/Sim/SimTerrainNavigation.cs').read_text(encoding='utf-8')
s=s.replace('            long start=Stopwatch.GetTimestamp();','            long planTiming=SimProfiler.Begin();\n            long start=Stopwatch.GetTimestamp();')
s=s.replace('            if(Log is not null)\n            {','            SimProfiler.End(SimSection.NavigationPlan,planTiming);\n            if(Log is not null)\n            {')
p.joinpath('SimTerrainNavigation.cs').write_text(s,encoding='utf-8')
s=Path('tools/ScaleBench/Program.cs').read_text(encoding='utf-8')
s=s.replace('    long allocation = 0;','''    long allocation = 0;
    var slow = new List<(double Ms,long Tick,Dictionary<string,double> Sections)>();
    var before = new long[Enum.GetValues<SimSection>().Length]; var after = new long[before.Length];''')
s=s.replace('        long memory = GC.GetAllocatedBytesForCurrentThread()', '        SimProfiler.CopyElapsedTicks(before);\n        long memory = GC.GetAllocatedBytesForCurrentThread()')
s=s.replace('        rails = Math.Max(rails, world.Projectiles.Count);','''        if(slow.Count<16 || samples[tick]>slow[^1].Ms)
        {
            SimProfiler.CopyElapsedTicks(after);
            var detail=Enum.GetValues<SimSection>().ToDictionary(x=>x.ToString(),x=>(after[(int)x]-before[(int)x])*1e6/Stopwatch.Frequency);
            slow.Add((samples[tick],world.Tick,detail));slow.Sort((a,b)=>b.Ms.CompareTo(a.Ms));
            if(slow.Count>16)slow.RemoveAt(16);
        }
        rails = Math.Max(rails, world.Projectiles.Count);''')
s=s.replace('        distanceMeters = distance, battlefield', '        slowTicks=slow.Select(x=>new { ms=x.Ms,tick=x.Tick,sectionsUs=x.Sections }),\n        distanceMeters = distance, battlefield')
p.joinpath('Program.cs').write_text(s,encoding='utf-8')
