$ErrorActionPreference='Stop'
$sfDest='docs/balance/structure_20261015'
$sfEvidence='shots/structure/evidence'
$sfExportName='SpaceFleet-20261015-structure-Windows-x64'
New-Item -ItemType Directory -Force -Path $sfDest,"$sfEvidence/raw","$sfEvidence/source/src/Game","$sfEvidence/source/src/View","$sfEvidence/source/data","$sfEvidence/source/tools/BattleBatch","$sfEvidence/source/tests/SimChecks","$sfEvidence/export-tests" | Out-Null
$sfBefore=@((Get-Content -Encoding UTF8 shots/lethality/after.losses.json -Raw | ConvertFrom-Json))+@((Get-Content -Encoding UTF8 shots/lethality/after-extra.losses.json -Raw | ConvertFrom-Json))
$sfAfter=@((Get-Content -Encoding UTF8 shots/structure/final.losses.json -Raw | ConvertFrom-Json))
$sfInitial=@((Get-Content -Encoding UTF8 shots/structure/initial/after.losses.json -Raw | ConvertFrom-Json))
function Get-LossSummary($sfRows) {
    $sfCauses=[ordered]@{}
    foreach($sfRow in $sfRows){foreach($sfCause in $sfRow.Causes.PSObject.Properties){$sfCauses[$sfCause.Name]=[int]$sfCauses[$sfCause.Name]+[int]$sfCause.Value}}
    return [ordered]@{
        battles=$sfRows.Count;totalShips=($sfRows | Measure-Object Ships -Sum).Sum
        destroyed=($sfRows | Measure-Object Destroyed -Sum).Sum;destroyedMean=($sfRows | Measure-Object Destroyed -Average).Average
        disabled=($sfRows | Measure-Object Disabled -Sum).Sum;repairs=($sfRows | Measure-Object Repairs -Sum).Sum
        meanSeconds=($sfRows | ForEach-Object {$_.Outcome.Time} | Measure-Object -Average).Average
        wins=@{Blue=@($sfRows | Where-Object {$_.Outcome.Winner -eq 0}).Count;Red=@($sfRows | Where-Object {$_.Outcome.Winner -eq 1}).Count;Draw=@($sfRows | Where-Object {$null -eq $_.Outcome.Winner}).Count}
        causes=$sfCauses
    }
}
$sfPairs=@(foreach($sfB in $sfBefore){
    $sfA=$sfAfter | Where-Object {$_.Seed -eq $sfB.Seed -and $_.Mirror -eq $sfB.Mirror}
    if($sfA.Ships -ne $sfB.Ships){throw 'Lineup mismatch'}
    [ordered]@{seed=$sfB.Seed;mirror=$sfB.Mirror;ships=$sfB.Ships;beforeDestroyed=$sfB.Destroyed;afterDestroyed=$sfA.Destroyed;beforeSeconds=$sfB.Outcome.Time;afterSeconds=$sfA.Outcome.Time}
})
$sfHashes=[ordered]@{}
$sfSource=@(Get-ChildItem src/Sim,src/Shared,data/ships -File)+@(Get-Item tools/BattleBatch/Program.cs,tools/BattleBatch/BattleBatch.csproj,tests/SimChecks/StructuralDamageChecks.cs,tests/SimChecks/AIChecks.cs,tests/SimChecks/FiringPositionChecks.cs,src/Game/CombatFeedback.cs,src/Game/CombatFeedbackChecks.cs,src/Game/WreckChecks.cs,src/Game/Hud.cs,src/Game/ScaleTest.cs,src/View/BallisticsView.cs)
foreach($sfFile in $sfSource){
    $sfRelative=[IO.Path]::GetRelativePath($PWD.Path,$sfFile.FullName).Replace('\','/')
    $sfHashes[$sfRelative]=(Get-FileHash -LiteralPath $sfFile.FullName).Hash.ToLowerInvariant()
    $sfTo=Join-Path "$sfEvidence/source" $sfRelative
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $sfTo) | Out-Null
    Copy-Item -LiteralPath $sfFile.FullName -Destination $sfTo
}
$sfExport=Get-Content -Encoding UTF8 "builds/$sfExportName/build-info.json" -Raw | ConvertFrom-Json
$sfSimTotal=(Select-String -LiteralPath shots/structure/sim-checks.log -Pattern '^PASS: (\d+)' | ForEach-Object {[int64]$_.Matches[0].Groups[1].Value} | Measure-Object -Sum).Sum
$sfCapacity=[ordered]@{}
Get-ChildItem data/ships -Filter '*.json' | ForEach-Object {$sfShip=Get-Content -LiteralPath $_.FullName -Encoding UTF8 -Raw | ConvertFrom-Json;$sfCapacity[$sfShip.id]=$sfShip.structureHitPoints}
$sfManifest=[ordered]@{
    date='2026-10-15';baseCommit=(& git rev-parse HEAD).Trim()
    baseline='Previous core-critical/repair-risk working tree. Reused its AFTER seed 1..4 normal/mirror runs and frozen candidate-bin. Baseline full sources are in ../lethality_20261015/evidence.zip; previous manifest hashes identify that exact state.'
    command='dotnet <frozen>/BattleBatch.dll --match-hull interceptor --seeds 1,2,3,4 --mirror --jobs 3 --output <path>'
    objective='Annihilation';battlefield='DeepSpace';timeLimitSeconds=1500;seeds=@(1,2,3,4);mirrored=$true
    scope='10 squads/team, identical seeded lineups, all AI; recorded at verdict. Structure wear applies to operational and disabled ships; repair never restores it.'
    capacity=$sfCapacity;before=(Get-LossSummary $sfBefore);initialRejected=(Get-LossSummary $sfInitial);after=(Get-LossSummary $sfAfter);pairs=$sfPairs
    tests=@{simChecks=$sfSimTotal;structureChecks=41;exportChecks=$sfExport.checks;hud='structure-hud.png (1600x900, 20% permanent structure + active sensor repair)'}
    frozenBinarySha256=@{before=(Get-FileHash shots/lethality/candidate-bin/BattleBatch.dll).Hash.ToLowerInvariant();initial=(Get-FileHash shots/structure/candidate-bin/BattleBatch.dll).Hash.ToLowerInvariant();after=(Get-FileHash shots/structure/final-bin/BattleBatch.dll).Hash.ToLowerInvariant()}
    sourceSha256=$sfHashes
    limitations=@('Only four paired seed clusters. Capacity was tuned on these same seeds, not independent holdout data; no final win-rate claim.','Initial rejected candidate used one-third of final capacity and predates the wreck-hit event flag fix; that flag only affects presentation.','Existing annihilation still ends on weighted force loss including non-recovering disable.','No new AI finishing priority, asteroid sample, performance benchmark, or player-input recording.','Firing-position and formation fixtures now keep their target alive to isolate navigation/orders from target death; original behavior assertions retained.')
}
$sfManifest | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 "$sfDest/manifest.json"
foreach($sfSuffix in @('csv','losses.json','summaries.json')){
    Copy-Item -LiteralPath "shots/lethality/after.$sfSuffix" -Destination "$sfDest/before-1-2.$sfSuffix"
    Copy-Item -LiteralPath "shots/lethality/after-extra.$sfSuffix" -Destination "$sfDest/before-3-4.$sfSuffix"
    Copy-Item -LiteralPath "shots/structure/final.$sfSuffix" -Destination "$sfDest/after.$sfSuffix"
}
Copy-Item -LiteralPath shots/structure/targeted.log,shots/structure/sim-checks.log -Destination $sfDest
Copy-Item -LiteralPath shots/structure-hud.png -Destination $sfDest
Copy-Item -Path shots/structure/final.*,shots/structure/*.log -Destination "$sfEvidence/raw"
Copy-Item -LiteralPath shots/structure/initial -Destination $sfEvidence -Recurse
Copy-Item -Path "shots/$sfExportName/*.log" -Destination "$sfEvidence/export-tests"
Copy-Item -Path tests/SimChecks/*.cs,tests/SimChecks/*.csproj -Destination "$sfEvidence/source/tests/SimChecks"
Copy-Item -LiteralPath shots/structure/save-evidence.ps1 -Destination $sfEvidence
Compress-Archive -Path "$sfEvidence/*" -DestinationPath "$sfDest/evidence.zip"
$sfManifest.before | ConvertTo-Json -Depth 4
$sfManifest.after | ConvertTo-Json -Depth 4
$sfPairs | Format-Table
