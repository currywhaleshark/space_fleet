import csv, json, re, statistics
from pathlib import Path

root=Path(__file__).resolve().parent
def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))
def profile(label):
    ticks={r['scope']:r for r in read_csv(root/(label+'.ticks.csv'))}
    sections={(r['scope'],r['section']):float(r['usPerTick']) for r in read_csv(root/(label+'.sections.csv'))}
    return dict(meanUs=float(ticks['All']['meanMs'])*1000,
        brawlP99Ms=float(ticks['Brawl']['p99Ms']) if ticks.get('Brawl',{}).get('p99Ms') else None,
        sections={s:sections['All',s] for s in ('Collision','TerrainCollision','Sensors','AIThink','Projectiles')})

report={'profiles':[], 'fps':{}, 'checks':{}}
for mode in ('Annihilation','Flagship','Domination'):
    for field in (1,2,3):
        prefix=f'profile-{mode}-field{field}-'
        if not (root/(prefix+'After.sections.csv')).exists(): continue
        a,b,c=[profile(prefix+suffix) for suffix in ('DeepSpace','Before','After')]
        row=dict(mode=mode,field=field,deep=a,before=b,after=c,ratio=c['meanUs']/a['meanUs'],changePercent=(c['meanUs']/b['meanUs']-1)*100)
        report['profiles'].append(row)
        print(f"{mode}/{field}: {b['meanUs']:.3f} -> {c['meanUs']:.3f} us ({row['changePercent']:.1f}%), ratio {row['ratio']:.3f}, p99 {b['brawlP99Ms']} -> {c['brawlP99Ms']}")
for path in sorted(root.glob('final-*-*.log')):
    text=path.read_text(encoding='utf-8-sig')
    if 'perf build:' not in text: continue
    samples=[dict(time=int(t),fps=float(fps)) for t,fps in re.findall(r'perf t=(\d+)s fps=([\d.]+)',text) if 590<=int(t)<=615]
    if samples:
        report['fps'][path.name]=dict(samples=samples,mean=statistics.mean(s['fps'] for s in samples),minimum=min(s['fps'] for s in samples),build=re.search(r'perf build:.*',text).group(),errors=len(re.findall('ERROR:|Exception',text)))
        print(path.name,report['fps'][path.name])
for path in [root/'final-sim.log', *root.glob('final-native-*.log')]:
    if not path.exists(): continue
    checks=re.findall(r'PASS: (\d+) ([^\n\r]+)',path.read_text(encoding='utf-8-sig'))
    report['checks'][path.name]=dict(total=sum(int(n) for n,_ in checks),groups=checks)
print('Checks:',{k:v['total'] for k,v in report['checks'].items()})
(root/'metrics.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
