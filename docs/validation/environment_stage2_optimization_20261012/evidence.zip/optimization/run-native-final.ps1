$ErrorActionPreference='Stop'
$optRoot=Join-Path (Get-Location).Path 'shots/environment_stage2_optimization'
while(-not (Test-Path -LiteralPath (Join-Path $optRoot 'measurement-done'))){Start-Sleep -Seconds 10}
. ./tools/godot.ps1
foreach($test in @('flow-test','environment-test')){
 $testLog=Join-Path $optRoot ('final-native-'+$test+'.log')
 $testArgs=@('--path',('"'+$ProjectDir+'"'),'--fixed-fps','60','--log-file',('"'+$testLog+'"'),'--',('--'+$test),'--seed=1')
 $checkProcess=Start-Process -FilePath $Godot -ArgumentList $testArgs -WindowStyle Hidden -PassThru
 if(-not $checkProcess.WaitForExit(90000)){Stop-Process -Id $checkProcess.Id -Force;throw ('Timeout '+$test)}
 $checkText=Get-Content -LiteralPath $testLog -Raw -Encoding UTF8
 if($checkProcess.ExitCode -ne 0 -or $checkText -match 'ERROR:|Exception' -or $checkText -notmatch 'PASS:'){throw ('Native check failed '+$test)}
 $checkText -split "`n" | Where-Object {$_ -match '^PASS:'}
}
$name='SpaceFleet-20261012-environment-stage2-optimized-Windows-x64'
./tools/export-windows.ps1 -Name $name *> (Join-Path $optRoot 'final-export.log')
if($LASTEXITCODE -ne 0){throw 'Export failed'}
Get-Content (Join-Path $optRoot 'final-export.log') -Tail 15 -Encoding UTF8
while(-not (Test-Path -LiteralPath (Join-Path $optRoot 'matrix-done'))){Start-Sleep -Seconds 10}
$buildDir=Join-Path $ProjectDir ('builds/'+$name)
foreach($case in @(@{Mode='Annihilation';Seed=1},@{Mode='Domination';Seed=5})) {
 $trace=Join-Path $optRoot ('final-release-'+$case.Mode+'.log')
 $arguments=@('--log-file',('"'+$trace+'"'),'--','--autoplay','--autoplay-speed=4',('--seed='+$case.Seed),'--blue-design=Earth','--red-design=Earth',('--objective='+$case.Mode),'--battlefield=AsteroidCluster','--field-seed=2','--advance=540','--perf-trace','--perf-seconds=40','--perf-no-sim-profile')
 $gameProcess=Start-Process -FilePath (Join-Path $buildDir 'SpaceFleet.exe') -ArgumentList $arguments -WorkingDirectory $buildDir -WindowStyle Hidden -PassThru
 if(-not $gameProcess.WaitForExit(300000)){Stop-Process -Id $gameProcess.Id -Force;throw 'Our Release FPS run timed out'}
 if($gameProcess.ExitCode -ne 0){throw ('FPS failed '+$gameProcess.ExitCode)}
 Write-Output ('Measured final Release FPS: '+$case.Mode)
}
New-Item -ItemType File -Force (Join-Path $optRoot 'native-done') | Out-Null
