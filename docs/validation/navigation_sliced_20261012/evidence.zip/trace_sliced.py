import pathlib
repo=pathlib.Path.cwd();root=pathlib.Path(__file__).resolve().parent;out=root/'sliced-trace';out.mkdir(exist_ok=True)
source=(repo/'tools/ScaleBench/Program.cs').read_text(encoding='utf-8-sig')
source=source.replace('SimProfiler.Enabled = false;\n    for (int tick = 0; tick < warmup; tick++) world.Step();','''SimProfiler.Enabled = false;
    var navigationPeaks=new List<object>();double navPeak=0;
    void NavigationPeak() { var e=world.Log!.Environment;if(e.PathSliceMaxMs<=navPeak)return;
        navPeak=e.PathSliceMaxMs;navigationPeaks.Add(new { tick=world.Tick,ms=navPeak,work=world.NavigationWorkLastTick,pending=world.PendingNavigation,gc0=GC.CollectionCount(0),gc1=GC.CollectionCount(1),gc2=GC.CollectionCount(2) }); }
    for (int tick = 0; tick < warmup; tick++) {world.Step();NavigationPeak();}''')
source=source.replace('var samples = new double[ticks];','''var samples = new double[ticks];
    double maxMeasuredNavigationMs=0;
    var elapsedBefore=new long[Enum.GetValues<SimSection>().Length];var elapsedAfter=new long[elapsedBefore.Length];
    var slow=new PriorityQueue<(long Tick,double Ms,double NavigationMs,double AIMs,double PDMs,double CollisionMs,double ProjectileMs),double>();''')
source=source.replace('long memory = GC.GetAllocatedBytesForCurrentThread(), start = Stopwatch.GetTimestamp();','''SimProfiler.CopyElapsedTicks(elapsedBefore);
        long memory = GC.GetAllocatedBytesForCurrentThread(), start = Stopwatch.GetTimestamp();''')
source=source.replace('allocation += GC.GetAllocatedBytesForCurrentThread() - memory;','''allocation += GC.GetAllocatedBytesForCurrentThread() - memory;
        NavigationPeak();
        SimProfiler.CopyElapsedTicks(elapsedAfter);
        maxMeasuredNavigationMs=Math.Max(maxMeasuredNavigationMs,(elapsedAfter[(int)SimSection.NavigationPlan]-elapsedBefore[(int)SimSection.NavigationPlan])*1000.0/Stopwatch.Frequency);
        if(slow.Count<20 || samples[tick]>slow.Peek().Ms) {
            double Delta(SimSection s)=>(elapsedAfter[(int)s]-elapsedBefore[(int)s])*1000.0/Stopwatch.Frequency;
            if(slow.Count==20)slow.Dequeue();
            slow.Enqueue((world.Tick,samples[tick],Delta(SimSection.NavigationPlan),Delta(SimSection.AI),Delta(SimSection.PointDefense),Delta(SimSection.Collision),Delta(SimSection.Projectiles)),samples[tick]);
        }''')
source=source.replace('distanceMeters = distance, battlefield', '''navigationPeaks,maxMeasuredNavigationMs,slowTicks=slow.UnorderedItems.Select(x=>new {tick=x.Element.Tick,ms=x.Element.Ms,navigationMs=x.Element.NavigationMs,aiMs=x.Element.AIMs,pdMs=x.Element.PDMs,collisionMs=x.Element.CollisionMs,projectileMs=x.Element.ProjectileMs}).OrderByDescending(x=>x.ms).ToArray(),
        distanceMeters = distance, battlefield''')
(out/'Program.cs').write_text(source,encoding='utf-8')
(out/'trace.csproj').write_text(f'''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings></PropertyGroup><ItemGroup>
<Reference Include="GodotSharp"><HintPath>{(repo/'.godot/mono/temp/bin/Debug/GodotSharp.dll').as_posix()}</HintPath></Reference>
<Compile Include="{(repo/'src/Sim').as_posix()}/*.cs" Link="Sim/%(Filename)%(Extension)" />
<EmbeddedResource Include="{(repo/'data/ships').as_posix()}/*.json" LogicalName="SpaceFleet.data.ships.%(Filename)%(Extension)" />
</ItemGroup></Project>''',encoding='utf-8')
