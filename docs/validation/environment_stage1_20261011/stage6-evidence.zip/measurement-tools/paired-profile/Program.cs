using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

string root=Path.GetFullPath(args[0]); string stage=args[1];
var baseline=new Runner(Path.Combine(root,"baseline-runner"));
var current=new Runner(Path.Combine(root,stage+"-runner"));
const int ticks=44856;
Console.WriteLine("Warming both versions...");
var warm=baseline.Run(ticks); var warmCurrent=current.Run(ticks);
if(warm.Summary!=warmCurrent.Summary) throw new Exception("Warmup results differ");
var rows=new List<object>();
for(int repeat=1;repeat<=3;repeat++)
{
    foreach(string name in repeat%2==1?new[]{"baseline",stage}:new[]{stage,"baseline"})
    {
        var result=(name=="baseline"?baseline:current).Run(ticks);
        if(result.Summary!=warm.Summary) throw new Exception("Measured result differs");
        rows.Add(new { repeat,name,result.UsPerTick,result.Sections }); Console.WriteLine($"{repeat} {name}: {result.UsPerTick:F3} us/tick");
    }
}
File.WriteAllText(Path.Combine(root,stage+"-inprocess-profile.json"),JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));

sealed class Runner
{
    readonly Assembly assembly; readonly Type worldType,configType;
    public Runner(string path)
    {
        var context=new Context(path); assembly=context.LoadFromAssemblyPath(Path.Combine(path,"BattleBatch.dll"));
        worldType=assembly.GetType("SpaceFleet.Sim.SimWorld")!;configType=assembly.GetType("SpaceFleet.Sim.BattleConfig")!;
    }
    public (double UsPerTick,string Summary,Dictionary<string,double> Sections) Run(int ticks)
    {
        object world=Activator.CreateInstance(worldType)!,config=Activator.CreateInstance(configType)!;
        configType.GetProperty("Seed")!.SetValue(config,1);
        assembly.GetType("SpaceFleet.Sim.BattleSetup")!.GetMethod("Spawn")!.Invoke(null,new[]{world,config});
        var step=(Action)worldType.GetMethod("Step")!.CreateDelegate(typeof(Action),world);
        GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();
        var profiler=assembly.GetType("SpaceFleet.Sim.SimProfiler")!; profiler.GetProperty("Enabled")!.SetValue(null,true); profiler.GetMethod("Reset")!.Invoke(null,null);
        var clock=Stopwatch.StartNew(); for(int i=0;i<ticks;i++) step(); clock.Stop();
        object log=worldType.GetProperty("Log")!.GetValue(world)!; log.GetType().GetMethod("Finish")!.Invoke(log,null);
        var sections=new Dictionary<string,double>();
        foreach(object entry in (System.Collections.IEnumerable)profiler.GetMethod("Snapshot")!.Invoke(null,null)!)
        {
            var t=entry.GetType();var value=t.GetProperty("Value")!.GetValue(entry)!;
            sections[t.GetProperty("Key")!.GetValue(entry)!.ToString()!]=(double)value.GetType().GetField("Item1")!.GetValue(value)!*1000/ticks;
        }
        return (clock.Elapsed.TotalMicroseconds/ticks,(string)log.GetType().GetMethod("Summary")!.Invoke(log,null)!,sections);
    }
    sealed class Context(string path):AssemblyLoadContext
    {
        protected override Assembly? Load(AssemblyName name)
        { string file=Path.Combine(path,name.Name+".dll");return File.Exists(file)?LoadFromAssemblyPath(file):null; }
    }
}
