$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/projectile_scaling_20261012'
if(!(Test-Path -LiteralPath (Join-Path $root 'measurement-done'))){throw 'Wait for isolated performance measurements first'}
& dotnet run --project tests/SimChecks -c Release --no-restore *> (Join-Path $root 'final-sim.log')
if($LASTEXITCODE -ne 0){throw 'Simulation checks failed'}
Write-Output 'All simulation checks passed'
Copy-Item -LiteralPath (Join-Path (Get-Location).Path 'shots/environment_stage2_optimization/runner') -Destination (Join-Path $root 'baseline-runner') -Recurse
Copy-Item -LiteralPath (Join-Path $root 'runner') -Destination (Join-Path $root 'final-runner') -Recurse
& dotnet run --project shots/environment_stage1/paired-block -c Release --no-restore -- $root final *> (Join-Path $root 'final-inprocess-block.log')
if($LASTEXITCODE -ne 0){throw 'Paired DeepSpace comparison failed'}
Write-Output 'Five paired comparisons passed'
foreach($mode in @('Annihilation','Flagship','Domination')) {
 foreach($field in @(0,1,2,3)) {
  $label='final-'+$mode+'-field'+$field
  $battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
  $reference=Join-Path (Get-Location).Path ('shots/environment_stage2_optimization/'+$label+'.summaries.json')
  & dotnet (Join-Path $root 'runner/BattleBatch.dll') --seeds 1,2,3,4,5,6,7,8,9,10 --mirror --jobs 6 --objective $mode --battlefield $battlefield --field-seed ([Math]::Max(1,$field)) --compare-summaries $reference --output (Join-Path $root ($label+'.csv')) *> (Join-Path $root ($label+'.log'))
  if($LASTEXITCODE -ne 0){throw ('Regression failed: '+$label)}
  Write-Output ('PASS '+$label+' 20/20')
 }
}
& dotnet build SpaceFleet.csproj --no-restore -p:SimOptimize=true *> (Join-Path $root 'final-build.log')
if($LASTEXITCODE -ne 0){throw 'Game build failed'}
New-Item -ItemType File -Force (Join-Path $root 'validation-done') | Out-Null
