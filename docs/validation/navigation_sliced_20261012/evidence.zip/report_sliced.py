import csv,json,pathlib,statistics,hashlib,zipfile,re
root=pathlib.Path(__file__).resolve().parent
def csvrows(name):
    with (root/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def data(name):return json.loads((root/name).read_text(encoding='utf-8-sig'))[0]
def stats(rows):
    number=lambda key:sum(float(r[key] or 0) for r in rows)
    phases=['Approach','Missile','Gunnery','Sniping','Brawl']
    duration=sum(number(p+'_seconds') for p in phases)
    return {'battles':len(rows),'blueWins':sum(r['winner']=='Blue' for r in rows),'redWins':sum(r['winner']=='Red' for r in rows),
      'medianOutcomeSeconds':statistics.median(float(r['outcomeTime']) for r in rows),
      'rails':number('Blue_rails')+number('Red_rails'),'railHits':number('Blue_railHits')+number('Red_railHits'),
      'missiles':number('Blue_missiles')+number('Red_missiles'),'missileHits':number('Blue_missileHits')+number('Red_missileHits'),
      'brawl60Battles':sum(float(r['Brawl_seconds'])>=60 for r in rows),
      'phaseFractions':{p:number(p+'_seconds')/duration for p in phases}}
report={'repeats':{},'extras':{},'battleComparisons':[]}
for variant in ['before','sliced']:
    rows=[data(f'sliced-pair-{i}-{variant}.json') for i in [1,2,3]]
    assert len({r['summarySha256'] for r in rows})==1,'Repeated combat diverged'
    report['repeats'][variant]={k:statistics.median(r[k] for r in rows) for k in ['meanMs','p99Ms','maxMs','allocatedBytesPerTick']}
    report['repeats'][variant]['summarySha256']=rows[0]['summarySha256']
    report['repeats'][variant]['sectionsUs']={k:statistics.median(r['sectionsUs'][k] for r in rows) for k in rows[0]['sectionsUs']}
    if variant=='sliced':report['repeats'][variant]['navigation']=rows[0]['navigation']
for case in ['field1','field3','late-field2']:
    if (root/f'sliced-extra-{case}-sliced.json').exists():
        report['extras'][case]={v:data(f'sliced-extra-{case}-{v}.json') for v in ['before','sliced']}
for mode in ['Annihilation','Flagship','Domination']:
    for field in range(4):
        label=f'{mode}-field{field}'
        if not(root/f'sliced-{label}.csv').exists():continue
        before=csvrows(f'final-{label}.csv');after=csvrows(f'sliced-{label}.csv')
        nav=csvrows(f'sliced-{label}.navigation-jobs.csv')
        completed=sum(int(r['completed']) for r in nav)
        report['battleComparisons'].append({'case':label,'before':stats(before),'after':stats(after),
          'navigation':{'completed':completed,'maxLatencySeconds':max(float(r['maxLatencySeconds']) for r in nav),
          'weightedMeanLatencySeconds':sum(int(r['completed'])*float(r['meanLatencySeconds']) for r in nav)/max(1,completed),
          'queuePeak':max(int(r['queuePeak']) for r in nav),'workPeak':max(int(r['workPeak']) for r in nav)},
          'collisionsBefore':sum(int(r['shipCollisions']) for r in csvrows(f'final-{label}.environment.csv')),
          'collisionsAfter':sum(int(r['shipCollisions']) for r in csvrows(f'sliced-{label}.environment.csv'))})
if (root/'sliced-noise-sliced-battle.csv').exists():
    report['independentSeeds']={v:stats(csvrows(f'sliced-noise-{v}.csv')) for v in ['battle','sliced-battle']}
(root/'sliced-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['extras']},ensure_ascii=False,indent=2))
