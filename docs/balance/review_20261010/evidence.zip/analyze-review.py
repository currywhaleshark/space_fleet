import collections, csv, hashlib, json, statistics, subprocess
from pathlib import Path

root = Path('shots/balance-review-20261010')
base = root / 'baseline'
previous = Path('docs/balance/mars_20261010')

def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

cases = {}
prior_matches = 0
for p in sorted(base.glob('*.csv')):
    if len(p.suffixes) != 1:
        continue
    battles, ships = read(p), read(p.with_suffix('.ships.csv'))
    expected_count = 16 if p.stem.startswith('duel-') else 40
    assert len(battles) == expected_count, p.name
    assert len({(b['seed'], b['mirror']) for b in battles}) == expected_count
    for battle in battles:
        assert battle['winner'] in ('Blue', 'Red', 'Draw'), (p.name, battle)
        for team in ('Blue', 'Red'):
            side = [s for s in ships if (s['seed'], s['mirror'], s['faction']) == (battle['seed'], battle['mirror'], team)]
            for key in ('rails', 'railHits', 'missiles', 'missileHits', 'torpedoes', 'torpedoHits', 'amFailures', 'amJettisons'):
                assert sum(int(s[key]) for s in side) == int(battle[f'{team}_{key}']), (p.name, key)
    summaries = json.loads(p.with_suffix('.summaries.json').read_text(encoding='utf-8-sig'))
    lookup = {(s['Seed'], s['Mirror']): s['Summary'] for s in summaries}
    for s in json.loads((previous / p.with_suffix('.summaries.json').name).read_text(encoding='utf-8-sig')):
        assert lookup[(s['Seed'], s['Mirror'])] == s['Summary'], (p.name, s['Seed'], s['Mirror'])
        prior_matches += 1
    cases[p.stem] = (battles, ships)
assert len(cases) == 40
assert sum(len(b) for b, _ in cases.values()) == 736

cross = [(case, b) for case in ('Earth-Mars', 'Mars-Earth') for b in cases[case][0]]
outcomes = collections.Counter()
for case, b in cross:
    design = b['winner'] if b['winner'] == 'Draw' else case.split('-')[0 if b['winner'] == 'Blue' else 1]
    outcomes[design] += 1
metrics = {}
for design in ('Earth', 'Mars'):
    for kind in ('Battleship', 'Escort', 'Interceptor'):
        ships = [s for case in ('Earth-Mars', 'Mars-Earth') for s in cases[case][1] if s['design'] == design and s['kind'] == kind]
        def total(k): return sum(float(s[k] or 0) for s in ships)
        metrics[f'{design}/{kind}'] = dict(count=len(ships), destroyed=int(total('destroyed')), disabled=int(total('disabled')),
            survivalMean=statistics.mean(float(s['survivalSeconds']) for s in ships),
            zeroRailShots=sum(int(s['rails']) == 0 for s in ships), emptyRailMagazine=sum(int(s['railRoundsRemaining']) == 0 for s in ships),
            railShots=int(total('rails')), railHits=int(total('railHits')), railRoundsRemainingMean=total('railRoundsRemaining')/len(ships),
            amLaunches=int(total('torpedoes')), amHits=int(total('torpedoHits')), amFailures=int(total('amFailures')), amJettisons=int(total('amJettisons')),
            shieldDamagePerShip=total('shieldDamageInflicted')/len(ships), moduleDamagePerShip=total('moduleDamageInflicted')/len(ships))

fleets = {name: dict(outcomes=dict(collections.Counter(b['winner'] for b in cases[name][0])),
            reasons=dict(collections.Counter(b['reason'] for b in cases[name][0])),
            medianOutcomeTime=statistics.median(float(b['outcomeTime']) for b in cases[name][0]))
          for name in ('Earth-Earth', 'Mars-Mars', 'Earth-Mars', 'Mars-Earth')}
# A layout seed is the unit here: its mirrors and exchanged designs are correlated observations.
seed_scores = []
for seed in map(str, range(1, 21)):
    sample = [(case, b) for case, b in cross if b['seed'] == seed]
    earth_wins = sum((case == 'Earth-Mars' and b['winner'] == 'Blue') or (case == 'Mars-Earth' and b['winner'] == 'Red') for case,b in sample)
    mars_wins = sum((case == 'Earth-Mars' and b['winner'] == 'Red') or (case == 'Mars-Earth' and b['winner'] == 'Blue') for case,b in sample)
    seed_scores.append(dict(seed=int(seed), earthWins=earth_wins, marsWins=mars_wins, draws=4-earth_wins-mars_wins))

telemetry_checks = 0
for p in (root / 'probes').glob('*.telemetry.csv'):
    rows = read(p)
    assert all(None not in row for row in rows)
    assert all(not row['rangeKm'] for row in rows if row['track'] == 'None')
    assert len(set((r['seed'], r['mirror'], r['time'], r['callsign']) for r in rows)) == len(rows)
    actual = json.loads(p.with_name(p.name.replace('.telemetry.csv', '.summaries.json')).read_text())
    expected = json.loads(p.with_name(p.name.replace('.telemetry.csv', '.expected.json')).read_text())
    assert actual == expected
    telemetry_checks += len(actual)
assert telemetry_checks == 24
result = dict(battles=736, previousSummariesMatched=prior_matches, telemetrySummariesMatched=telemetry_checks,
              fleet=fleets, crossFleetOutcomes=dict(outcomes), crossFleetMetrics=metrics, pairedSeeds=seed_scores)
(root/'diagnosis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
