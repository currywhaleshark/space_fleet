from pathlib import Path
import shutil

root=Path('shots/defense_ai_scaling_20261012')
source=root/'baseline-source'
source.mkdir(parents=True,exist_ok=True)
for path in Path('src/Sim').glob('*.cs'): shutil.copy2(path,source/path.name)
p=root/'detail';p.mkdir(exist_ok=True)
names=['SimProfiler','SimMissiles','DroneCombat','SimAI','Gunnery']
excluded=';'.join('../../../src/Sim/'+name+'.cs' for name in names)
p.joinpath('detail.csproj').write_text(f'''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings></PropertyGroup><ItemGroup><Reference Include="GodotSharp"><HintPath>../../../.godot/mono/temp/bin/Debug/GodotSharp.dll</HintPath></Reference><Compile Include="../../../src/Sim/*.cs" Exclude="{excluded}"/><Compile Include="../../../tools/ScaleBench/Program.cs"/><EmbeddedResource Include="../../../data/ships/*.json" LogicalName="SpaceFleet.data.ships.%(Filename)%(Extension)"/></ItemGroup></Project>''',encoding='utf-8')
for name in names:
    s=source.joinpath(name+'.cs').read_text(encoding='utf-8')
    if name=='SimProfiler':
        s=s.replace('TerrainCollision, Post,','TerrainCollision, PDCollect, PDSelect, DefenseLine, FriendlyLine, AutoFire, SmallEngage, AMEngage, Post,')
    if name=='SimMissiles':
        s=s.replace('            _pdMissileCandidates.Clear();','            long collect=SimProfiler.Begin();\n            _pdMissileCandidates.Clear();')
        s=s.replace('            if (_pdMissileCandidates.Count == 0','            SimProfiler.End(SimSection.PDCollect,collect);\n            if (_pdMissileCandidates.Count == 0')
        s=s.replace('                Missile? threat = null;','                long select=SimProfiler.Begin();\n                Missile? threat = null;')
        s=s.replace('                if (threat is null && raider is null','                SimProfiler.End(SimSection.PDSelect,select);\n                if (threat is null && raider is null')
    if name=='DroneCombat':
        signature='private bool ClearDefenseLine(Vec3d origin,Vec3d target,ShipBody? intended=null)'
        s=s.replace(signature,'''private bool ClearDefenseLine(Vec3d origin,Vec3d target,ShipBody? intended=null)
    { long t=SimProfiler.Begin(); try { return ClearDefenseLineCore(origin,target,intended); } finally { SimProfiler.End(SimSection.DefenseLine,t); } }
    private bool ClearDefenseLineCore(Vec3d origin,Vec3d target,ShipBody? intended=null)''')
    if name=='SimAI':
        signature='public bool FriendlyInLine(ShipBody shooter, Vec3d muzzle, Vector3 direction, float range)'
        s=s.replace(signature,'''public bool FriendlyInLine(ShipBody shooter, Vec3d muzzle, Vector3 direction, float range)
    { long t=SimProfiler.Begin(); try { return FriendlyInLineCore(shooter,muzzle,direction,range); } finally { SimProfiler.End(SimSection.FriendlyLine,t); } }
    private bool FriendlyInLineCore(ShipBody shooter, Vec3d muzzle, Vector3 direction, float range)''')
        s=s.replace('        EngageSmallTarget(brain);','        long t=SimProfiler.Begin();\n        EngageSmallTarget(brain);\n        SimProfiler.End(SimSection.SmallEngage,t);')
        s=s.replace('        EngageAntimatter(brain, target, track);','        t=SimProfiler.Begin();\n        EngageAntimatter(brain, target, track);\n        SimProfiler.End(SimSection.AMEngage,t);')
    if name=='Gunnery':
        s=s.replace('            bool shot = TryAutoFireGun', '            long t=SimProfiler.Begin();\n            bool shot = TryAutoFireGun')
        s=s.replace('            if (shot)', '            SimProfiler.End(SimSection.AutoFire,t);\n            if (shot)')
    p.joinpath(name+'.cs').write_text(s,encoding='utf-8')
