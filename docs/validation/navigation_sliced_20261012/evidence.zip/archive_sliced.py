import hashlib,json,pathlib,zipfile,re,statistics,subprocess,csv
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path.cwd()
assert (root/'native-done').exists(),'Validation pipeline must finish first'
subprocess.run(['python',str(root/'report_sliced.py')],stdout=subprocess.DEVNULL,check=True)
report=json.loads((root/'sliced-report.json').read_text(encoding='utf-8'))
assert len(report['battleComparisons'])==12
for row in report['battleComparisons']:assert row['navigation']['workPeak']<=12000
hashes=json.loads((root/'sliced-source-hashes.json').read_text(encoding='utf-8-sig'))
for item in hashes:assert hashlib.sha256(pathlib.Path(item['Path']).read_bytes()).hexdigest().upper()==item['Hash'],item['Path']
tests=(root/'sliced-checks.log').read_text(encoding='utf-8-sig');assert 'Exception' not in tests
count=sum(int(n) for n in re.findall(r'^PASS: (\d+)',tests,re.M))
fps=[]
for file in sorted(root.glob('fps-*.log')):
    text=file.read_text(encoding='utf-8-sig');assert 'ERROR:' not in text and 'Exception' not in text
    samples=[]
    for line in text.splitlines():
        match=re.search(r'perf t=([\d.]+).*?fps=([\d.]+)',line)
        if match and 590<=float(match[1])<=615:samples.append(float(match[2]))
    fps.append({'file':file.name,'samples':len(samples),'mean':statistics.mean(samples) if samples else None,'min':min(samples) if samples else None})
output=repo/'docs/validation/navigation_sliced_20261012';output.mkdir(parents=True,exist_ok=True)
files=set()
for pattern in ['sliced-*.json','sliced-*.csv','sliced-*.log','fps-*.log','native-*.log','export.log','finish_sliced.ps1','resume_sliced.ps1','native.ps1','archive_sliced.py','report_sliced.py','append_sliced_tables.py','trace_sliced.py','excluded-overlap-*.json']:
    files.update(p for p in root.glob(pattern) if p.is_file())
exportLogs=repo/'shots/SpaceFleet-20261012-navigation-sliced-Windows-x64'
with zipfile.ZipFile(output/'evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(files):archive.write(file,file.name)
    for file in sorted(exportLogs.glob('*.log')):archive.write(file,'export/'+file.name)
package=repo/'builds/SpaceFleet-20261012-navigation-sliced-Windows-x64.zip'
with zipfile.ZipFile(package) as archive:assert archive.testzip() is None
release=repo/'builds/SpaceFleet-20261012-navigation-sliced-Windows-x64'
binary=[*release.rglob('SpaceFleet.exe'),*release.rglob('SpaceFleet.dll'),*release.rglob('SpaceFleet.Sim.dll')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification={'baselineCommit':'cab9a5b9ca00f8bff12e72b0f31f60a054d66f61','exactCacheCommit':'96decb5','change':'결과 변경: deterministic incremental navigation approved by user',
 'simChecks':count,'sourceHashes':hashes,'report':report,'fps':fps,
 'runnerHashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'before-runner/ScaleBench.dll',root/'after-runner/ScaleBench.dll',root/'sliced-runner/ScaleBench.dll',root/'battle-runner/BattleBatch.dll',root/'sliced-battle-runner/BattleBatch.dll',root/'sliced-check-runner/SimChecks.dll']},
 'binaries':{str(p.relative_to(repo)):sha(p) for p in binary},'packageSha256':sha(package),'evidenceSha256':sha(output/'evidence.zip'),
 'excludedMeasurements':['excluded-overlap-trace-field3.json','excluded-overlap-late-before.json'],
 'limits':['Synthetic 240-ship simulation excludes rendering/audio/network costs','Manual flight not evaluated','Fixed work credits do not guarantee a wall-clock deadline on every CPU']}
(output/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':count,'fps':fps,'packageSha256':verification['packageSha256']},ensure_ascii=False,indent=2))
