$ErrorActionPreference='Stop'
. ./tools/godot.ps1
$root=Join-Path $ProjectDir 'shots/navigation_scaling_20261012'
dotnet build tools/BattleBatch/BattleBatch.csproj -c Release -o (Join-Path $root 'battle-runner') *> (Join-Path $root 'battle-build.log')
if($LASTEXITCODE -ne 0){throw 'Battle build'}
foreach($mode in @('Annihilation','Flagship','Domination')) {
 foreach($field in @(0,1,2,3)) {
  $label="final-$mode-field$field"
  $battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
  $reference=Join-Path $ProjectDir "shots/defense_ai_scaling_20261012/$label.summaries.json"
  dotnet (Join-Path $root 'battle-runner/BattleBatch.dll') --seeds 1,2,3,4,5,6,7,8,9,10 --mirror --jobs 6 --objective $mode --battlefield $battlefield --field-seed ([Math]::Max(1,$field)) --compare-summaries $reference --output (Join-Path $root "$label.csv") *> (Join-Path $root "$label.log")
  if($LASTEXITCODE -ne 0){throw "Regression failed: $label"}
  Write-Output "PASS $label 20/20"
 }
}
dotnet build SpaceFleet.csproj --no-restore -p:SimOptimize=true *> (Join-Path $root 'game-build.log')
if($LASTEXITCODE -ne 0){throw 'Game build'}
