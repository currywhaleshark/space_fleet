import csv,json,statistics,hashlib
from pathlib import Path
root=Path('shots/environment_stage2')
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def total(rs,k):return sum(float(x[k] or 0) for x in rs)
def median(values):
 v=[float(x) for x in values if x!=''];return statistics.median(v) if v else None
result={}
for mode in ['Annihilation','Flagship','Domination']:
 for field in [0,1,2,3]:
  prefix=f'stage6-{mode}' if field==0 else f'stage6-asteroid-{mode}-field{field}'
  p=root/(prefix+'.csv')
  if not p.exists():continue
  rs=rows(p);assert len(rs)==20,p
  env=rows(p.with_suffix('.environment.csv'));ships=rows(p.with_suffix('.ships.csv'))
  wins={w:sum(r['winner']==w for r in rs) for w in ['Blue','Red','Draw','Unresolved']}
  normal=sum(r['winner']=='Blue' and r['mirror']=='0' for r in rs);mirror=sum(r['winner']=='Blue' and r['mirror']=='1' for r in rs)
  damage=total(ships,'moduleDamageInflicted')
  r=dict(battles=20,wins=wins,blueNormal=normal,blueMirror=mirror,blueWinGapPoints=10*abs(normal-mirror),medianVerdict=median([x['outcomeTime'] for x in rs]),
         firstContact=median([min(float(x['Blue_contact'] or 1e9),float(x['Red_contact'] or 1e9)) for x in rs]),
         firstDamage=median([min(float(x[k]) for k in ['Blue_missileHit','Red_missileHit','Blue_railHit','Red_railHit'] if x[k]) for x in rs]),
         phases={phase:total(rs,phase+'_seconds')/sum(total(rs,p+'_seconds') for p in ['Approach','Missile','Gunnery','Sniping','Brawl']) for phase in ['Approach','Missile','Gunnery','Sniping','Brawl']},
         terrain={k:total(env,k) for k in env[0] if k not in ['seed','mirror','collisionEnergyJ']},
         railRange=total(ships,'railRangeSum')/max(1,total(ships,'railRangeSamples')),
         classes={kind:dict(count=sum(x['kind']==kind for x in ships),operational=sum(x['operational']=='1' and x['kind']==kind for x in ships),
             surviving=sum(x['destroyed']=='0' and x['kind']==kind for x in ships),meanSurvival=statistics.mean(float(x['survivalSeconds']) for x in ships if x['kind']==kind),
             moduleDamageShare=sum(float(x['moduleDamageInflicted']) for x in ships if x['kind']==kind)/max(1,damage)) for kind in ['Battleship','Escort','Interceptor']},
         torpedoes=total(ships,'torpedoes'),torpedoHits=total(ships,'torpedoHits'))
  for suffix in ['navigation','sight','cover']:
   data=rows(p.with_suffix('.'+suffix+'.csv'));r[suffix]={k:total(data,k) for k in data[0] if k not in ['seed','mirror','fieldSeed','enabled']}
  result[f'{mode}/{field}']=r
(root/'stage6-matrix-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('Complete groups',len(result),'battles',len(result)*20)
