$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/environment_stage2_optimization'
$old=Join-Path (Get-Location).Path 'shots/environment_stage2/stage6-runner/BattleBatch.dll'
$current=Join-Path $root 'runner/BattleBatch.dll'
foreach($mode in @('Annihilation','Flagship','Domination')) {
 foreach($field in @(1,2,3)) {
  foreach($variant in @('DeepSpace','Before','After')) {
   $runner=if($variant -eq 'Before'){$old}else{$current}
   $battlefield=if($variant -eq 'DeepSpace'){'DeepSpace'}else{'AsteroidCluster'}
   $label='profile-'+$mode+'-field'+$field+'-'+$variant
   & dotnet $runner --seeds 1 --objective $mode --battlefield $battlefield --field-seed $field --profile --output (Join-Path $root ($label+'.csv')) *> (Join-Path $root ($label+'.log'))
   if($LASTEXITCODE -ne 0){throw ('Profile failed: '+$label)}
   Write-Output ('Measured: '+$label)
  }
 }
}
& dotnet $current --seeds 1 --objective Domination --battlefield AsteroidCluster --field-seed 1 --slow-ticks --output (Join-Path $root 'final-slow.csv') *> (Join-Path $root 'final-slow.log')
if($LASTEXITCODE -ne 0){throw 'Slow tick diagnostic failed'}
# The identical frozen runner was already measured as no-small-runner before
# native rebuilds; preserve that full five-pair result rather than re-running.
Copy-Item -LiteralPath (Join-Path $root 'no-small-inprocess-block.log') -Destination (Join-Path $root 'final-inprocess-block.log')
Copy-Item -LiteralPath (Join-Path $root 'no-small-inprocess-block.json') -Destination (Join-Path $root 'final-inprocess-block.json')
New-Item -ItemType File -Force (Join-Path $root 'measurement-done') | Out-Null
& (Join-Path $root 'verify-matrix.ps1')
