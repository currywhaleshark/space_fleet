param([ValidateSet('fleet','duels')][string]$Mode)
$ErrorActionPreference='Stop'
$runner = 'tools/BattleBatch/bin/Release/net8.0/BattleBatch.dll'
$output = 'shots/balance-review-20261010/baseline'
New-Item -ItemType Directory -Force $output | Out-Null
$pairs = @(@('Earth','Earth'),@('Mars','Mars'),@('Earth','Mars'),@('Mars','Earth'))
if ($Mode -eq 'fleet') {
  foreach ($pair in $pairs) {
    $name = "$($pair[0])-$($pair[1])"
    Write-Output "START $name $(Get-Date -Format o)"
    & dotnet $runner --seeds ((1..20) -join ',') --mirror --jobs 3 --minutes 25 --blue-design $pair[0] --red-design $pair[1] --output "$output/$name.csv" *> "$output/$name.log"
    if ($LASTEXITCODE -ne 0) { throw "Failed $name" }
    Get-Content -Encoding UTF8 "$output/$name.log" -Tail 1
  }
} else {
  foreach ($kind in @('Battleship','Escort','Interceptor')) {
    $ranges = if ($kind -eq 'Interceptor') {@(4000,12000,30000)} elseif ($kind -eq 'Escort') {@(12000,45000,80000)} else {@(20000,70000,130000)}
    foreach ($range in $ranges) { foreach ($pair in $pairs) {
      $name = "duel-$kind-$range-$($pair[0])-$($pair[1])"
      Write-Output "START $name $(Get-Date -Format o)"
      & dotnet $runner --seeds ((1..8) -join ',') --mirror --jobs 1 --minutes 25 --duel $kind --distance $range --blue-design $pair[0] --red-design $pair[1] --output "$output/$name.csv" *> "$output/$name.log"
      if ($LASTEXITCODE -ne 0) { throw "Failed $name" }
      Get-Content -Encoding UTF8 "$output/$name.log" -Tail 1
    }}
  }
}
