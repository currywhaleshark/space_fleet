from pathlib import Path
import csv,json,re
root=Path('shots/projectile_scaling_20261012');old=Path('shots/environment_stage2_optimization')
completed=re.findall(r'PASS (final-\w+-field\d) 20/20', (root/'validate.log').read_text(encoding='utf-8-sig'))
suffixes=('summaries.json','ships.csv','am.csv','probes.csv','environment.csv','environment-events.csv','sight.csv','cover.csv','navigation.csv')
for name in completed:
    for suffix in suffixes:
        a,b=old/(name+'.'+suffix),root/(name+'.'+suffix)
        if suffix=='navigation.csv':
            def stable(p):
                with p.open(encoding='utf-8-sig',newline='') as stream:
                    return [{k:v for k,v in r.items() if k not in ('buildMs','planMs')} for r in csv.DictReader(stream)]
            assert stable(a)==stable(b),(name,suffix)
        else:assert a.read_bytes()==b.read_bytes(),(name,suffix)
checkpoint=dict(battles=20*len(completed),groups=completed,allDetailsEqual=True,navigationExcludes=['buildMs','planMs'])
(root/'partial-matrix.json').write_text(json.dumps(checkpoint,indent=2),encoding='utf-8')
print(json.dumps(checkpoint))
