$ErrorActionPreference='Stop'
. ./tools/godot.ps1
$root=Join-Path (Get-Location).Path 'shots/defense_ai_scaling_20261012'
if(!(Test-Path -LiteralPath (Join-Path $root 'measurement-done'))){throw 'Wait for scale and paired-block measurements'}
python shots/defense_ai_scaling_20261012/slow-diagnostic.py
& dotnet build shots/defense_ai_scaling_20261012/slow-detail/slow.csproj -c Release -o (Join-Path $root 'slow-runner') *> (Join-Path $root 'slow-build.log')
if($LASTEXITCODE -ne 0){throw 'slow diagnostic build'}
& dotnet (Join-Path $root 'slow-runner/slow.dll') --groups 10 --repeats 1 --battlefield AsteroidCluster --field-seed 2 --output (Join-Path $root 'slow-asteroid.json') *> (Join-Path $root 'slow-asteroid.log')
if($LASTEXITCODE -ne 0){throw 'slow diagnostic'}
Write-Output 'Large asteroid slow-tick diagnostic complete'
foreach($mode in @('Annihilation','Flagship','Domination')) {
 foreach($field in @(0,1,2,3)) {
  foreach($variant in @('before','after')) {
   $runner=if($variant -eq 'before'){'baseline-runner'}else{'final-runner'}
   $battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
   $label="profile-$mode-field$field-$variant"
   & dotnet (Join-Path $root "$runner/BattleBatch.dll") --seeds 1 --objective $mode --battlefield $battlefield --field-seed ([Math]::Max(1,$field)) --profile --output (Join-Path $root "$label.csv") *> (Join-Path $root "$label.log")
   if($LASTEXITCODE -ne 0){throw $label}
   Write-Output "Measured $label"
  }
 }
}
& ./shots/defense_ai_scaling_20261012/validate.ps1
& ./shots/defense_ai_scaling_20261012/native.ps1
