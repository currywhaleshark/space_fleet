from pathlib import Path
import subprocess
root=Path('shots/projectile_scaling_20261012')
baseline=root/'baseline-source';baseline.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-tree','-r','--name-only','d15d525','src/Sim'],text=True).splitlines()
for name in files:
    if name.endswith('.cs'):
        baseline.joinpath(Path(name).name).write_bytes(subprocess.check_output(['git','show','d15d525:'+name]))
s=baseline.joinpath('SimBallistics.cs').read_text(encoding='utf-8')
s=s[s.index('    private void StepProjectiles<TEnvironment>'):]
s=s.replace('private void StepProjectiles<TEnvironment>','internal void ReferenceStepProjectiles<TEnvironment>')
s=s.replace('PrepareProjectileBounds();','ReferencePrepareProjectileBounds();')
s=s.replace('FirstSmallHit(', 'ReferenceFirstSmallHit(')
prep=baseline.joinpath('SimBallistics.cs').read_text(encoding='utf-8')
prep=prep[prep.index('    private void PrepareProjectileBounds()'):prep.index('    internal void RecordImpact')]
prep=prep.replace('PrepareProjectileBounds()', 'ReferencePrepareProjectileBounds()')
small=baseline.joinpath('SmallTargetCombat.cs').read_text(encoding='utf-8')
small=small[small.index('    private object? FirstSmallHit'):small.index('    /// <summary>Shared player/AI')]
small=small.replace('FirstSmallHit(', 'ReferenceFirstSmallHit(').replace('MovingSphereHit(', 'ReferenceMovingSphereHit(')
header='''// Frozen d15d525 projectile traversal and small-target narrow phase.
// Test-only reference: full target scan, original live hull/shield radius reads.
using System;
using Godot;
namespace SpaceFleet.Sim;
public sealed partial class SimWorld
{
    internal void StepProjectilesForCheck(double dt,double time,bool reference)
    {
        if (!reference) StepProjectiles(dt,time);
        else if (Obstacles.Count == 0) ReferenceStepProjectiles<EmptyEnvironment>(dt,time);
        else ReferenceStepProjectiles<FixedEnvironment>(dt,time);
    }
'''
Path('tests/SimChecks/ProjectileReference.cs').write_text(header+prep+small+s,encoding='utf-8')
