import csv,hashlib,json,re,statistics,zipfile,subprocess
from pathlib import Path

root=Path('shots/environment_stage1'); output=Path('docs/validation/environment_stage1_20261011')
name='SpaceFleet-20261011-environment-stage1-Windows-x64'
build=Path('builds')/name; logs=Path('shots')/name
report=json.loads((output/'stage6.json').read_text(encoding='utf-8'))
assert report['summaryMatches']=={'Annihilation':20,'Flagship':20}
report['baselineProfiles']={mode:{x['scope']+'/'+x['section']:float(x['usPerTick']) for x in csv.DictReader((root/f'baseline-profile-{mode}.sections.csv').open(encoding='utf-8-sig'))}
    for mode in ['Annihilation','Domination']}
info=json.loads((build/'build-info.json').read_text(encoding='utf-8-sig'))
archive=Path('builds')/(name+'.zip')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    entries=len(z.infolist())
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest in Path(str(archive)+'.sha256').read_text()
report['export']={**info,'checksCount':sum(int(re.search(r'PASS: (\d+)',x).group(1)) for x in info['checks']),
    'archiveSha256':digest,'archiveBytes':archive.stat().st_size,'archiveEntries':entries,'zipCrcVerified':True}
report['environmentPresentationChecks']=19
report['contactMemoryChecks']=22
report['dominationIdenticalToStage5']={suffix:(root/('stage6-Domination'+suffix)).read_bytes()==(root/('stage5-Domination'+suffix)).read_bytes()
    for suffix in ['.summaries.json','.ships.csv','.environment.csv','.am.csv','.probes.csv']}
assert all(report['dominationIdenticalToStage5'].values())
report['emptySpacePairedMeasurements']={}
for p in sorted(root.glob('stage6-inprocess*.json')):
    rows=json.loads(p.read_text(encoding='utf-8-sig'))
    if not rows:continue
    if 'baselineUs' in rows[0]:
        a=[x['baselineUs'] for x in rows];b=[x['currentUs'] for x in rows]
    else:
        a=[x['UsPerTick'] for x in rows if x['name']=='baseline'];b=[x['UsPerTick'] for x in rows if x['name']=='stage6']
    report['emptySpacePairedMeasurements'][p.name]={'baselineMedianUs':statistics.median(a),'currentMedianUs':statistics.median(b),
        'deltaPercent':100*(statistics.median(b)/statistics.median(a)-1),'rows':rows,
        'profilerEnabled':p.name=='stage6-inprocess-profile.json',
        'sourcePhase':'final specialized loops' if p.name=='stage6-inprocess-block.json' else 'earlier diagnostic; before final loop specialization'}
report['emptySpaceAcceptanceMeasurement']='stage6-inprocess-block.json'
assert report['emptySpacePairedMeasurements']['stage6-inprocess-block.json']['deltaPercent']<=1
report['runnerSha256']={name:hashlib.sha256((root/name/'BattleBatch.dll').read_bytes()).hexdigest() for name in ['baseline-runner','stage6-runner']}
report['measurementMethod']='All timing trials retained. Acceptance uses profiler-off same-process isolated assemblies, identical seed and 44856 ticks. The profile diagnostic enables instrumentation and records section costs. Whole battles alternate; pinned uses affinity mask 4; block alternates the order every 120 ticks on the same logical processor. One warmup per version excluded. Summary checked on every run. No concurrent build/test/export during measurement.'
changed=set(subprocess.check_output(['git','diff','--name-only','ffb00a1'],text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
report['sourceSha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(changed)
    if Path(p).is_file() and p.startswith(('src/','tests/','tools/'))}
report['screenshots']=['stage6-memory.png','stage6-map.png','stage6-camera.png','stage6-fire.png']
report['knownLimits']=['Domination has 2 stuck episodes; path planning is deliberately out of scope.','Human camera/cover play feel unverified.']
with zipfile.ZipFile(output/'stage6-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.glob('stage6-*')):
        if p.is_file() and p.name!='stage6-final-verification.log':z.write(p,p.name)
    for folder in ['paired','paired-profile','paired-pinned','paired-block']:
        for p in (root/folder).glob('*'):
            if p.is_file():z.write(p,'measurement-tools/'+folder+'/'+p.name)
    for p in logs.glob('*.log'):z.write(p,'export/'+p.name)
    for p in root.glob('baseline-profile-*'):
        if p.is_file():z.write(p,'baseline/'+p.name)
    z.write(build/'build-info.json','export/build-info.json')
    for file in ['verify-stage.ps1','report.py','finish_stage6.py']:
        z.write(root/file,'measurement-tools/'+file)
report['evidenceSha256']=hashlib.sha256((output/'stage6-evidence.zip').read_bytes()).hexdigest()
(output/'stage6.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k in ['summaryMatches','fullSimChecks','flowChecks','export','dominationIdenticalToStage5']},ensure_ascii=False,indent=2))
