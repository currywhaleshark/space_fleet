import csv, hashlib, json, pathlib, zipfile
root=pathlib.Path(__file__).resolve().parent
previous=root.parent/'defense_ai_scaling_20261012'
output=pathlib.Path('docs/validation/navigation_cache_20261012')
output.mkdir(parents=True,exist_ok=True)
comparisons=[]
for mode in ['Annihilation','Flagship','Domination']:
    for field in range(4):
        name=f'final-{mode}-field{field}'
        for suffix in ['summaries.json','ships.csv','am.csv','probes.csv','environment-events.csv','environment.csv','sight.csv','cover.csv']:
            a=(previous/f'{name}.{suffix}').read_bytes();b=(root/f'{name}.{suffix}').read_bytes()
            assert a==b,(name,suffix)
        for suffix,excluded in [('csv',{'wallSeconds'}),('navigation.csv',{'buildMs','planMs'})]:
            def read(base):
                with (base/f'{name}.{suffix}').open(encoding='utf-8-sig',newline='') as f:
                    return [{k:v for k,v in row.items() if k not in excluded} for row in csv.DictReader(f)]
            assert read(previous)==read(root),(name,suffix)
        comparisons.append({'case':name,'battles':20,'allGameplayRecordsMatch':True})
files=[]
for pattern in ['asteroid-*-before.*','asteroid-*-after.*','final-*','exact-sim.log','check-build.log','measure.ps1','validate.ps1','archive_exact.py','replay-8.log','diagnostic.paths.json']:
    files.extend(p for p in root.glob(pattern) if p.is_file())
with zipfile.ZipFile(output/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.name)
verification={'baselineCommit':'cab9a5b9ca00f8bff12e72b0f31f60a054d66f61','scope':'Exact directional candidate cache only; excludes subsequent incremental navigation',
 'simChecks':5395339,'comparisons':comparisons,'sourceHashes':json.loads((root/'final-source-hashes.json').read_text(encoding='utf-8-sig')),
 'evidenceSha256':hashlib.sha256((output/'evidence.zip').read_bytes()).hexdigest(),'nativeChecks':'Deferred to final incremental build; no intermediate export'}
(output/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
print('240 exact battles: all gameplay records match')
