$ErrorActionPreference='Stop'
$root=Join-Path (Get-Location).Path 'shots/navigation_scaling_20261012'
if(!(Test-Path -LiteralPath (Join-Path $root 'validation-done'))){throw 'Finish CPU regressions before native checks'}
. ./tools/godot.ps1
foreach($test in @('flow-test','environment-test')) {
 $testLog=Join-Path $root "native-$test.log"
 $arguments=@('--path',('"'+$ProjectDir+'"'),'--fixed-fps','60','--log-file',('"'+$testLog+'"'),'--',"--$test",'--seed=1')
 $child=Start-Process -FilePath $Godot -ArgumentList $arguments -WindowStyle Hidden -PassThru
 if(-not $child.WaitForExit(90000)){Stop-Process -Id $child.Id -Force;throw "Our native check timed out $test"}
 $lines=Get-Content -LiteralPath $testLog -Raw -Encoding UTF8
 if($child.ExitCode -ne 0 -or $lines -match 'ERROR:|Exception' -or $lines -notmatch 'PASS:'){throw "Native check failed $test"}
 $lines -split "`n" | Where-Object {$_ -match '^PASS:'}
}
$name='SpaceFleet-20261012-navigation-sliced-Windows-x64'
& ./tools/export-windows.ps1 -Name $name *> (Join-Path $root 'export.log')
if($LASTEXITCODE -ne 0){throw 'Export failed'}
Get-Content (Join-Path $root 'export.log') -Tail 12 -Encoding UTF8
foreach($case in @(@{Mode='Annihilation';Seed=1},@{Mode='Domination';Seed=5})) {
 foreach($variant in @('Debug','Release-before','Release-after')) {
  $buildName=if($variant -eq 'Release-before'){'SpaceFleet-20261012-defense-scaling-Windows-x64'}else{$name}
  $output=Join-Path $ProjectDir "builds/$buildName"
  $log=Join-Path $root ('fps-'+$variant+'-'+$case.Mode+'.log')
  $exe=if($variant -eq 'Debug'){$Godot}else{Join-Path $output 'SpaceFleet.exe'}
  $cwd=if($variant -eq 'Debug'){$ProjectDir}else{$output}
  $arguments=@('--log-file',('"'+$log+'"'))
  if($variant -eq 'Debug'){$arguments+=@('--path',('"'+$ProjectDir+'"'))}
  $arguments+=@('--','--autoplay','--autoplay-speed=4',('--seed='+$case.Seed),'--blue-design=Earth','--red-design=Earth',('--objective='+$case.Mode),'--battlefield=AsteroidCluster','--field-seed=2','--advance=540','--perf-trace','--perf-seconds=40','--perf-no-sim-profile')
  $child=Start-Process -FilePath $exe -ArgumentList $arguments -WorkingDirectory $cwd -WindowStyle Hidden -PassThru
  if(-not $child.WaitForExit(300000)){Stop-Process -Id $child.Id -Force;throw 'Our FPS process timed out'}
  $lines=Get-Content -LiteralPath $log -Raw -Encoding UTF8
  if($child.ExitCode -ne 0 -or $lines -match 'ERROR:|Exception' -or $lines -notmatch 'perf t='){throw "FPS failed $log"}
  Write-Output ('Measured '+$variant+' '+$case.Mode)
 }
}
python (Join-Path $root 'trace_sliced.py')
dotnet build (Join-Path $root 'sliced-trace/trace.csproj') -c Release -o (Join-Path $root 'sliced-trace-runner') *> (Join-Path $root 'sliced-trace-build.log')
if($LASTEXITCODE -ne 0){throw 'Trace build'}
dotnet (Join-Path $root 'sliced-trace-runner/trace.dll') --groups 10 --repeats 1 --battlefield AsteroidCluster --field-seed 2 --output (Join-Path $root 'sliced-trace.json') *> (Join-Path $root 'sliced-trace.log')
if($LASTEXITCODE -ne 0){throw 'Trace run'}
New-Item -ItemType File -Force (Join-Path $root 'native-done') | Out-Null
