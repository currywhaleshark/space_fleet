$ErrorActionPreference='Stop'
. ./tools/godot.ps1
$root=Join-Path (Get-Location).Path 'shots/defense_ai_scaling_20261012'
foreach($repeat in @(1,2,3)) {
 foreach($groups in @(1,2,4,10)) {
  $variants=if($repeat%2 -eq 1){@('before','after')}else{@('after','before')}
  foreach($variant in $variants) {
   $label="scale-$groups-$repeat-$variant"
   & dotnet (Join-Path $root "scale-$variant/ScaleBench.dll") --groups $groups --repeats 1 --output (Join-Path $root "$label.json") *> (Join-Path $root "$label.log")
   if($LASTEXITCODE -ne 0){throw $label}
   Get-Content (Join-Path $root "$label.log") -Tail 1 -Encoding UTF8
  }
 }
}
foreach($case in @('asteroid','late')) {
 foreach($variant in @('before','after')) {
  $label="$case-$variant"
  $field=if($case -eq 'asteroid'){'AsteroidCluster'}else{'DeepSpace'}
  $warmup=if($case -eq 'late'){180}else{15}
  & dotnet (Join-Path $root "scale-$variant/ScaleBench.dll") --groups 10 --warmup $warmup --seconds 60 --repeats 1 --battlefield $field --field-seed 2 --output (Join-Path $root "$label.json") *> (Join-Path $root "$label.log")
  if($LASTEXITCODE -ne 0){throw $label}
  Write-Output $label
  Get-Content (Join-Path $root "$label.log") -Tail 1 -Encoding UTF8
 }
}
& dotnet run --project shots/environment_stage1/paired-block -c Release --no-restore -- $root final *> (Join-Path $root 'final-inprocess-block.log')
if($LASTEXITCODE -ne 0){throw 'paired block'}
Write-Output 'Five paired full-battle DeepSpace measurements complete'
New-Item -ItemType File -Force (Join-Path $root 'measurement-done') | Out-Null
