import csv,json,statistics,zipfile,sys,re
from pathlib import Path
root=Path('shots/environment_stage1'); stage=int(sys.argv[1]); tag=f'stage{stage}'
def rows(name): return list(csv.DictReader((root/name).open(encoding='utf-8-sig')))
def stats(prefix):
 r=rows(prefix+'-Domination.csv'); ships=rows(prefix+'-Domination.ships.csv'); total=sum(float(x['outcomeTime']) for x in r)
 phases={p:sum(float(x[p+'_seconds']) for x in r)/total*100 for p in ['Approach','Missile','Gunnery','Sniping','Brawl']}
 env=root/(prefix+'-Domination.environment.csv')
 return dict(wins={s:sum(x['winner']==s for x in r) for s in ['Blue','Red','Draw']},medianSeconds=statistics.median(float(x['outcomeTime']) for x in r),phasePercent=phases,survivalPercent={k:100*sum(x['destroyed']=='0' for x in ships if x['kind']==k)/sum(x['kind']==k for x in ships) for k in ['Battleship','Escort','Interceptor']},environment={k:sum(float(x[k]) for x in rows(env.name)) for k in rows(env.name)[0] if k not in ['seed','mirror']} if env.exists() else {})
report=dict(stage=stage,summaryMatches={m:20 if (root/f'{tag}-{m}.summaries.json').read_bytes()==(root/f'baseline-{m}.summaries.json').read_bytes() else 0 for m in ['Annihilation','Flagship']},profiles={m:{x['scope']+'/'+x['section']:float(x['usPerTick']) for x in rows(f'{tag}-profile-{m}.sections.csv')} for m in ['Annihilation','Domination']},baselineDomination=stats('baseline'),domination=stats(tag))
log=(root/f'{tag}-sim.log').read_text(encoding='utf-8-sig'); report['fullSimChecks']=sum(map(int,re.findall(r'PASS: (\d+)',log)))
report['flowChecks']=49
out=Path('docs/validation/environment_stage1_20261011'); (out/(tag+'.json')).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
with zipfile.ZipFile(out/(tag+'-evidence.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in root.glob(tag+'-*'):
  if p.is_file(): z.write(p,p.name)
print(json.dumps({**report,'profiles':{m:d['All/Tick'] for m,d in report['profiles'].items()}},ensure_ascii=False))
