$ErrorActionPreference='Stop'
. ./tools/godot.ps1
$root=Join-Path $ProjectDir 'shots/navigation_scaling_20261012'
dotnet build tools/ScaleBench/ScaleBench.csproj -c Release -o (Join-Path $root 'sliced-runner') *> (Join-Path $root 'sliced-build.log')
if($LASTEXITCODE -ne 0){throw 'Scale build'}
Get-ChildItem src/Sim -File -Filter '*.cs' | ForEach-Object { [PSCustomObject]@{Path=$_.FullName;Hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash} } | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $root 'sliced-source-hashes.json')
foreach($repeat in @()){
 $variants=if($repeat%2){@('before','sliced')}else{@('sliced','before')}
 foreach($variant in $variants){
  dotnet (Join-Path $root "$variant-runner/ScaleBench.dll") --groups 10 --repeats 1 --battlefield AsteroidCluster --field-seed 2 --output (Join-Path $root "sliced-pair-$repeat-$variant.json") *> (Join-Path $root "sliced-pair-$repeat-$variant.log")
  if($LASTEXITCODE -ne 0){throw "$repeat $variant"}
  Get-Content -Encoding UTF8 (Join-Path $root "sliced-pair-$repeat-$variant.log") -Tail 1
 }
}
foreach($case in @(@{Label='late-field2';Field=2;Warmup=180})){
 foreach($variant in @('before','sliced')){
  $label='sliced-extra-'+$case.Label+'-'+$variant
  dotnet (Join-Path $root "$variant-runner/ScaleBench.dll") --groups 10 --repeats 1 --warmup $case.Warmup --seconds 60 --battlefield AsteroidCluster --field-seed $case.Field --output (Join-Path $root "$label.json") *> (Join-Path $root "$label.log")
  if($LASTEXITCODE -ne 0){throw $label}
  Write-Output $label
  Get-Content -Encoding UTF8 (Join-Path $root "$label.log") -Tail 1
 }
}
dotnet (Join-Path $root 'sliced-check-runner/SimChecks.dll') *> (Join-Path $root 'sliced-checks.log')
if($LASTEXITCODE -ne 0){throw 'Sim checks'}
Write-Output 'Full SimChecks passed'
dotnet build tools/BattleBatch/BattleBatch.csproj -c Release -o (Join-Path $root 'sliced-battle-runner') *> (Join-Path $root 'sliced-battle-build.log')
if($LASTEXITCODE -ne 0){throw 'Battle build'}
foreach($mode in @('Annihilation','Flagship','Domination')){
 foreach($field in @(0,1,2,3)){
  $label="sliced-$mode-field$field";$battlefield=if($field -eq 0){'DeepSpace'}else{'AsteroidCluster'}
  $arguments=@((Join-Path $root 'sliced-battle-runner/BattleBatch.dll'),'--seeds','1,2,3,4,5,6,7,8,9,10','--mirror','--jobs','6','--objective',$mode,'--battlefield',$battlefield,'--field-seed',([Math]::Max(1,$field)),'--output',(Join-Path $root "$label.csv"))
  if($field -eq 0 -and $mode -ne 'Domination'){$arguments+=@('--compare-summaries',(Join-Path $root "final-$mode-field0.summaries.json"))}
  dotnet @arguments *> (Join-Path $root "$label.log")
  if($LASTEXITCODE -ne 0){throw $label}
  Write-Output "Completed $label 20/20"
 }
}
# Independent seed cohort measures natural outcome variation at the focal terrain.
foreach($variant in @('battle','sliced-battle')){
 $label="sliced-noise-$variant"
 dotnet (Join-Path $root "$variant-runner/BattleBatch.dll") --seeds 11,12,13,14,15,16,17,18,19,20 --mirror --jobs 6 --objective Annihilation --battlefield AsteroidCluster --field-seed 2 --output (Join-Path $root "$label.csv") *> (Join-Path $root "$label.log")
 if($LASTEXITCODE -ne 0){throw $label}
 Write-Output "Completed $label 20/20"
}
dotnet build SpaceFleet.csproj --no-restore -p:SimOptimize=true *> (Join-Path $root 'sliced-game-build.log')
if($LASTEXITCODE -ne 0){throw 'Game build'}
New-Item -ItemType File -Force (Join-Path $root 'validation-done') | Out-Null
& (Join-Path $root 'native.ps1')

