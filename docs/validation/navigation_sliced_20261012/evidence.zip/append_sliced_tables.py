import json,pathlib
root=pathlib.Path(__file__).resolve().parent
r=json.loads((root/'sliced-report.json').read_text(encoding='utf-8'))
assert len(r['battleComparisons'])==12 and 'independentSeeds' in r
lines=['\n<!-- navigation-sliced-validation -->','\n### 24척 전투 결과 비교','\n각 행은 시드 1~10 × 정/역배치 20판이다. 0은 심우주, 1·2·3은 소행성 배치다. 승수는 Blue/Red/무승부, 발사/명중은 양쪽 합계이며 시간은 판정 시각 중앙값이다. 변경 후 결과를 이전과 동일하다고 처리하지 않는다.','',
'| 목표 / 배치 | 승수 전→후 | 판정 초 전→후 | 레일건 발사/명중 전→후 | 미사일 발사/명중 전→후 |',
'|---|---|---:|---:|---:|']
def wins(x):return f"{x['blueWins']}/{x['redWins']}/{x['battles']-x['blueWins']-x['redWins']}"
for row in r['battleComparisons']:
    b,a=row['before'],row['after']
    lines.append(f"| {row['case']} | {wins(b)} → {wins(a)} | {b['medianOutcomeSeconds']:.1f} → {a['medianOutcomeSeconds']:.1f} | {b['rails']:.0f}/{b['railHits']:.0f} → {a['rails']:.0f}/{a['railHits']:.0f} | {b['missiles']:.0f}/{b['missileHits']:.0f} → {a['missiles']:.0f}/{a['missileHits']:.0f} |")
lines+=['','국면 비율은 전체 기록 시간의 접근/미사일/포격/저격/난전 순서(%).','',
'| 목표 / 배치 | 국면 비율 전 | 국면 비율 후 | 난전 60초 이상 판 수 전→후 | 지형 충돌 전→후 |',
'|---|---|---|---:|---:|']
for row in r['battleComparisons']:
    b,a=row['before'],row['after']
    phases=lambda x:'/'.join(f'{n*100:.1f}' for n in x['phaseFractions'].values())
    lines.append(f"| {row['case']} | {phases(b)} | {phases(a)} | {b['brawl60Battles']} → {a['brawl60Battles']} | {row['collisionsBefore']} → {row['collisionsAfter']} |")
lines+=['','추가 독립 시드 11~20 × 정/역배치(소행성 배치 2·섬멸, 각 20판):','',
'| 코드 / 시드 | 승수 | 판정 초 중앙값 | 레일건 발사/명중 | 미사일 발사/명중 |','|---|---|---:|---:|---:|']
focal=next(row for row in r['battleComparisons'] if row['case']=='Annihilation-field2')
for label,s in [('기준 / 1~10',focal['before']),('분할 / 1~10',focal['after']),('기준 / 11~20',r['independentSeeds']['battle']),('분할 / 11~20',r['independentSeeds']['sliced-battle'])]:
    lines.append(f"| {label} | {wins(s)} | {s['medianOutcomeSeconds']:.1f} | {s['rails']:.0f}/{s['railHits']:.0f} | {s['missiles']:.0f}/{s['missileHits']:.0f} |")
nav=[row['navigation'] for row in r['battleComparisons']]
lines+=['',f"240판의 완료 요청은 {sum(x['completed'] for x in nav):,}건, 최대 대기 {max(x['maxLatencySeconds'] for x in nav):.3f}초, 최대 동시 대기 {max(x['queuePeak'] for x in nav)}건이다. 모든 판에서 틱 작업 상한을 지켰다. 이 배치 검증은 jobs=6으로 실행했으므로 경과시간 및 여기의 밀리초 값은 단독 성능 표에 사용하지 않는다.",'']
target=pathlib.Path('docs/BALANCE_perf.md');text=target.read_text(encoding='utf-8-sig').split('\n<!-- navigation-sliced-validation -->')[0]
target.write_text(text+'\n'.join(lines),encoding='utf-8')
