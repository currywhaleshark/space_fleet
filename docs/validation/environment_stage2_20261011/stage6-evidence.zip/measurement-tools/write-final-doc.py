from pathlib import Path
import json,csv,re,statistics
root=Path('shots/environment_stage2')
matrix=json.loads((root/'stage6-matrix-analysis.json').read_text())
perf=json.loads((root/'stage6-performance-analysis.json').read_text())
assert len(matrix)==12 and len(perf['profilePairs'])==9 and perf['emptyPaired'] and len(perf['fps'])==2 and len(perf['releaseFps'])==2
export=json.loads((root/'stage6-export.json').read_text())
info=json.loads(Path('builds/SpaceFleet-20261011-environment-stage2-Windows-x64/build-info.json').read_text(encoding='utf-8-sig'))
count=sum(int(re.search(r'PASS: (\d+)',s).group(1)) for s in info['checks'])
labels={'Annihilation':'섬멸','Flagship':'기함','Domination':'점령'}
def name(key):
 mode,field=key.split('/');return labels[mode]+(' · 심우주' if field=='0' else ' · 소행성 '+field)
t='''
## 6차 — 화면·최적화·최종 검증

- 지도: 2px보다 작은 바위를 생략하고 윤곽의 대비를 낮췄다. 기준 평면까지 높이선을 표시하며 함선·거점·표적을 나중에 그린다. 레이더는 중심 20km 이내, 반지름 2km 이상 바위만 윤곽을 표시하고 구 테두리 밖의 선을 잘라 낸다.
- 수동 조종의 충돌 경고는 현재 속도의 4초 예상 이동에 선체 경계 반지름을 더해 판단한다. 30m/s 이하는 표시하지 않으며 진행 방향에 주황색 도형만 표시한다. 조준·사격 판정은 바꾸지 않는다.
- 카메라는 장애물을 만나면 즉시 당기고 0.2초 유지 후 0.45초 시상수로 복귀한다. 표시 메시의 표면 오차를 위한 여유도 더했다. FOV와 조준 방향, 망원 궤적은 유지한다. 180프레임 연속 복귀·원거리 좌표·충돌 경고를 포함한 장면 검사 204개 통과. 사람이 조종하는 실제 비행감·카메라·엄폐 체감은 **미확인**이다.
- 구형 구성체의 박스 거리와 선분 교차는 퇴화 캡슐의 일반 계산을 생략한다. 수정 전 수식을 검사 프로젝트에 보존해 무작위 20,000개를 직접 대조했다. 전체 **532,249개**, 장면 전환 **51개** 통과. `TerrainCollision` 하위 구간을 추가했다. 심우주 점령 20전과 소행성 시드 1 섬멸 20전은 5차와 바이트 일치한다.
- 12종 공유 메시·재질 하나·MultiMesh 12개·그림자 끔을 유지한다. `--asteroid-preview=fleet|memory|map|warning`은 스크린샷 모드에서만 동작하는 고정 위치 검사다. 군집 원경/함대/기억 표적/전체 지도/경고 5장을 실제 렌더러로 확인했다(`stage6-wide/fleet/memory/map/warning.png`). 이미지와 로그는 근거 ZIP에 포함한다.

### 240전 비교

Earth/Earth 24척, 목표 3종 × {심우주, 소행성 배치 1/2/3} × 전투 시드 1~10 × 정/역배치. 심우주 섬멸·기함 **40전은 기준과 바이트 일치**. 아래 각 행은 20전이다. 모든 전투가 판정까지 완료됐고 무승부/미판정은 0이었다. 전투 배치는 병렬 실행했으며 벽시 실행시간을 성능 비교에 사용하지 않는다.

| 전장 | Blue:Red | 정/역 Blue 승(각 10판) | 판정 중앙값(초) | 첫 피해 중앙값(초) | 레일건 평균 발사거리(km) | 미사일/저격/난전 비중(%) |
|---|---:|---:|---:|---:|---:|---:|
'''
for key,r in matrix.items():
 t+=f"| {name(key)} | {r['wins']['Blue']}:{r['wins']['Red']} | {r['blueNormal']}/{r['blueMirror']} | {r['medianVerdict']:.1f} | {r['firstDamage']:.1f} | {r['railRange']/1000:.1f} | "+'/'.join(f"{r['phases'][p]*100:.1f}" for p in ['Missile','Sniping','Brawl'])+' |\n'
t+='''
첫 접촉 중앙값은 모든 조합에서 0초로, 이 센서/배치 조건에서는 전장 간 차이를 설명하지 못한다. 국면 비중은 기존 전투 로그의 분류에 따른 누적 시간 비율이다. 발사거리는 명중만이 아니라 모든 기록된 레일건 발사를 포함한다.

| 전장 | 차단 레일/미사일/AM/프로브 | 잠금 소실(횟수/초)·기억 재획득 | 함선 충돌/피해·갇힘 | 경로 계획/실패 | 사선 기동/발사 재개/실패 |
|---|---:|---:|---:|---:|---:|
'''
for key,r in matrix.items():
 e=r['terrain'];n=r['navigation'];s=r['sight']
 t+=f"| {name(key)} | "+'/'.join(str(int(e['blocked'+v])) for v in ['Rails','Missiles','Torpedoes','Probes'])+f" | {e['blueLockLosses']+e['redLockLosses']:.0f}/{e['blueLostSeconds']+e['redLostSeconds']:.1f} · {e['blueReacquisitions']+e['redReacquisitions']:.0f} | {e['shipCollisions']:.0f}/{e['collisionModuleDamage']:.1f} · {e['stuckDetections']:.0f} | {n['plans']:.0f}/{n['failures']:.0f} | {s['starts']:.0f}/{s['successes']:.0f}/{s['failures']:.0f} |\n"
t+='''
실패한 사선 탐색에는 출발 후보 없음도 포함한다. 경로 실패 후에는 정지/국소 회피와 재시도를 사용한다. 모든 배치 재생성은 0회였다. 심우주 점령의 기존 갇힘 2건은 최종 20전에서 관측되지 않았으나, 소행성 점령 시드 1/2에서 각 2건이 남았다. 해당 상태를 재현한 `stage6-stuck-trace.log`에서 4척 모두 엔진 또는 자세제어 모듈이 파괴돼 있었다. 3척은 유효 추진 0%, 나머지 1척은 50%였다. 2척은 목적지 직선이 열려 있었고 다른 2척은 활성 우회 경로를 갖고 있었다. 손상과 이동 불능이 동반된 사례이며 건강한 함선의 경로 실패로 단정할 수 없다. 반대로 손상만이 유일한 원인이라고 입증한 것도 아니므로 손상함의 회피·복구와 별도로 후속 검토한다.

| 전장 | 전함/호위/요격 전투가능 비율(%) | 평균 생존시간 전함/호위/요격(초) | 내부 피해 기여 전함/호위/요격(%) | 강습 참가/도달/도달 전 손실 | AM 발사/명중 |
|---|---:|---:|---:|---:|---:|
'''
for key,r in matrix.items():
 classes=list(r['classes'].values());c=r['cover']
 t+=f'| {name(key)} | '+'/'.join(f"{x['operational']/x['count']*100:.1f}" for x in classes)+' | '+'/'.join(f"{x['meanSurvival']:.1f}" for x in classes)+' | '+'/'.join(f"{x['moduleDamageShare']*100:.1f}" for x in classes)+f" | {c['entrants']:.0f}/{c['arrivals']:.0f}/{c['lostBeforeArrival']:.0f} | {r['torpedoes']:.0f}/{r['torpedoHits']:.0f} |\n"
t+='''
강습 도달 기록은 장애물이 있는 전장에서만 수집한다. 따라서 심우주 섬멸/기함의 0은 '강습하지 않음'을 뜻하지 않는다. 다른 전투 지표와 별도로 해석해야 한다. 전투가능 비율은 종료 시 격침/무력화를 제외한 비율이고, 생존시간은 기존 선박 로그의 판정 기준이다.

판단:

- **교전은 섬멸전에서 대체로 가까워졌다.** 평균 발사거리 33.5→29~31km, 난전 12.4→15.7~18.2%. 미사일 국면은 줄었으나 시드 2의 저격 비중은 오히려 증가했다. 기함전 시드 2는 발사거리가 늘었으므로 모든 목표에서 근접전이 늘었다고 말할 수 없다.
- **소행성 자체는 섬멸전의 어뢰 사용 기회를 늘렸다.** 발사 53→76~88, 명중 41→43~73. 그러나 시드 3은 43/77로 명중률이 낮아졌고, 5차 켜기/끄기의 작은 차이를 전체 지형 효과와 혼동하면 안 된다.
- **정/역 편차가 커진 조합도 있다.** 섬멸 시드 3의 차이는 50%p(심우주 40%p), 점령 시드 1도 50%p(심우주 20%p). 생성 위치·구성체·표면의 점대칭 검사는 통과했고 재생성도 없었다. 각 방향 10판은 1승이 10%p여서 표본이 작다. 전투 난수·표적 선택과 지형의 상호작용 가능성을 배제할 수 없으며, 생성기 편향이라고 단정할 근거도 부족하다.
- **한 함종의 일관된 우위는 확인하지 못했다.** 섬멸전에서 호위함의 종료 전투가능 비율은 58.3→45.8~54.2%로 낮아진다. 점령전 요격함은 심우주 14.5%, 소행성 15~22%로 여전히 많이 손실된다. 무기·센서·함체 수치를 바꿔 이를 가리지는 않았다.

### 단독 성능

Release, 같은 목표·전투 시드 1, jobs=1. 각 소행성 배치 직전에 심우주 대조를 실행했다. 일반 단독 측정은 앞선 차수처럼 CPU affinity를 강제하지 않는다. 초기에 단일 코어를 강제했던 별도 조건의 결과는 `stage6-pinned-profile-*`로 보존하고 아래 비교와 섞지 않는다. 난전이 없었던 표본은 p99를 `—`로 표시한다.

| 목표/배치 | 심우주 µs/틱 | 소행성 µs/틱 | 배율 | 난전 p99(ms) | 충돌/그중 지형/센서/AI 판단 µs/틱 |
|---|---:|---:|---:|---:|---:|
'''
for r in perf['profilePairs']:
 a=r['asteroids'];p99=f"{r['brawlP99']:.3f}" if r['brawlP99'] is not None else '—'
 t+=f"| {labels[r['mode']]}/{r['fieldSeed']} | {r['deep']['Tick']:.3f} | {a['Tick']:.3f} | {r['ratio']:.3f} | {p99} | "+'/'.join(f"{a[k]:.3f}" for k in ['Collision','TerrainCollision','Sensors','AIThink'])+' |\n'
e=perf['emptyPaired'];t+=f"\n빈 공역은 1단계와 같은 CPU affinity 4·120틱 교차·1쌍 예열+5쌍 측정이다. 중앙값 {e['baselineMedian']:.3f}→{e['currentMedian']:.3f}µs/틱, **{e['deltaPercent']:+.3f}%**. 각 반복의 요약도 기준과 같았다. 모든 반복은 `stage6-inprocess-block.json/log`에 보존한다.\n"
t+='\n| 실제 Debug ×4, 배치 2 (298개 바위) | 590~615초 표본 평균 FPS | 표본 최소 FPS | 오류 |\n|---|---:|---:|---:|\n'
for mode,r in perf['fps'].items():t+=f"| {labels[mode]} | {r['mean']:.1f} | {r['minimum']:.1f} | {r['errors']} |\n"
t+='\n| 배포 Release ×4, 동일 배치·전투 시드 | 590~615초 표본 평균 FPS | 표본 최소 FPS | 오류 |\n|---|---:|---:|---:|\n'
for mode,r in perf['releaseFps'].items():t+=f"| {labels[mode]} | {r['mean']:.1f} | {r['minimum']:.1f} | {r['errors']} |\n"
t+='''
FPS는 RTX 2060·1600×900·Vulkan Forward+에서 렌더·음향을 켜고 540초부터 진입해 실시간 40초간 기록했다. 정상 배속이 아니라 ×4 자동 관전이다. 10분 상태가 존재하도록 배치 2의 정배치에서 판정 시각이 650초보다 늦은 첫 시드(섬멸 1, 점령 5)를 사용했다. 동시 배치/빌드 없이 각각 단독 실행했으며 스크린샷용 fixed-fps는 쓰지 않았다. Native 로그에 10분 스냅숏과 프레임/렌더 구간이 있다. Release 수치는 실제 배포본의 참고값이며 지시서의 Debug 기준을 대체하지 않는다. 두 설정은 별도 실행이므로 전 프레임이 같은 전투 시점에 일대일 대응하는 비교도 아니다.

Debug는 표본 평균과 최소 모두 30 FPS에 미달했다. 10분 부근 섬멸은 physics 약 71~114ms/프레임 중 sim 70~112ms, 점령은 physics 219~266ms 중 sim 216~264ms였다. 이 측정에서는 ×4로 누적 처리하는 시뮬레이션 시간이 프레임 대부분을 차지한다. 배포 Release와 Debug의 차이는 크지만 최적화 빌드 여부만으로 원인을 전부 확정하지 않는다.

**성능 완료 판정은 보류한다.** 평균 1.5배를 초과하는 조합과 난전 p99 1ms 초과가 남아 있다. 점령 시드 1의 난전 평균은 충돌 169.3µs(그중 지형 84.9), 센서 77.5, 미사일 106.1이다. 센서는 약 0.25초마다 갱신을 묶어 실행하므로 평균 77.5µs/틱은 실제 갱신 시 대략 1.2ms 규모가 된다(갱신 간격에서 추정). 개별 p99 틱의 구간별 기여를 직접 분리한 자료는 아니므로 단일 원인으로 단정하지 않는다. 섬멸 시드 3은 난전 AI 판단 평균 98.4µs로, 노출 경로 재계획 비용도 후속 최적화 대상이다. 지시서 5절의 “못 맞추면 구간별 표와 원인을 보고하고 사용자 판단을 받는다”에 따라 이 상태를 최종 성능 합격으로 처리하지 않는다.

### 실행본·재현 자료

'''
t+=f"- Windows 실행본: `builds/SpaceFleet-20261011-environment-stage2-Windows-x64/SpaceFleet.exe` 및 폴더 전체 ZIP. .NET 런타임 포함. 배포본 검사 {len(info['checks'])}종 **{count:,}개 통과**, ZIP CRC/SHA-256 확인.\n- ZIP SHA-256: `{export['sha256']}`.\n- 배포 시 소스 기준 커밋은 `{info['sourceCommit']}`이며 6차의 로컬 변경이 포함된 빌드다. 정확한 소스/실행기 해시는 `validation/environment_stage2_20261011/stage6.json`에 기록한다.\n- 240전 상세 JSON/CSV, 각 프로파일, 모든 교차 측정, 실제 FPS/배포 로그, 5개 이미지는 `stage6-evidence.zip`에 보존한다. 소행성 재현: `BattleBatch --battlefield AsteroidCluster --field-seeds 1,2,3 --seeds 1,2,3,4,5,6,7,8,9,10 --mirror --objective Annihilation`; 나머지 두 목표도 같은 방식이다.\n- 남은 항목: 성능 기준 승인/추가 최적화 결정, 손상함 정체 4건의 개선 여부, 더 큰 표본의 전장 공정성, 수동 비행·카메라·엄폐 체감.\n"
p=Path('docs/ENVIRONMENT_stage2.md');old=p.read_text(encoding='utf-8').split('\n## 6차 —')[0];p.write_text(old+t,encoding='utf-8')
Path('shots/environment_stage2/stage6-acceptance.json').write_text(json.dumps({'emptyPercent':e['deltaPercent'],'emptyWithinOnePercent':abs(e['deltaPercent'])<=1,'meanRatioWithin1_5':all(x['ratio']<=1.5 for x in perf['profilePairs']),'brawlP99Within1ms':all(x['brawlP99'] is None or x['brawlP99']<=1 for x in perf['profilePairs']),'fpsAtLeast30':all(x['minimum']>=30 for x in perf['fps'].values()),'nativeChecks':count,'manualFeel':'unverified'},indent=2),encoding='utf-8')
print('Stage 6 report written; native checks',count)
