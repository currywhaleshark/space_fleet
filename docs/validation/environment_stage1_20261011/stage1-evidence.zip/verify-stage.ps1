param([Parameter(Mandatory=$true)][int]$Stage)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path "$PSScriptRoot/../..")
$sfRoot = Join-Path (Get-Location) 'shots/environment_stage1'
dotnet build tools/BattleBatch/BattleBatch.csproj -c Release --no-restore -v quiet
if ($LASTEXITCODE -ne 0) { throw 'Batch build failed' }
$sfRunner = Join-Path $sfRoot "stage$Stage-runner"
New-Item -ItemType Directory -Force $sfRunner | Out-Null
Copy-Item -Path tools/BattleBatch/bin/Release/net8.0/* -Destination $sfRunner -Recurse -Force
foreach ($sfMode in @('Annihilation','Flagship','Domination')) {
    $sfArgs = @('--seeds','1,2,3,4,5,6,7,8,9,10','--mirror','--minutes','25','--jobs','4','--objective',$sfMode,'--output',"$sfRoot/stage$Stage-$sfMode.csv")
    if ($sfMode -ne 'Domination' -or $Stage -le 2) { $sfArgs += @('--compare-summaries',"$sfRoot/baseline-$sfMode.summaries.json") }
    dotnet "$sfRunner/BattleBatch.dll" @sfArgs *> "$sfRoot/stage$Stage-$sfMode.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$sfRoot/stage$Stage-$sfMode.log" -Tail 8; throw "Stage $Stage $sfMode failed" }
    Write-Output "Stage $Stage ${sfMode}: 20 battles complete."
}
foreach ($sfMode in @('Annihilation','Domination')) {
    dotnet "$sfRunner/BattleBatch.dll" --seeds 1 --minutes 25 --jobs 1 --profile --objective $sfMode --output "$sfRoot/stage$Stage-profile-$sfMode.csv" *> "$sfRoot/stage$Stage-profile-$sfMode.log"
    if ($LASTEXITCODE -ne 0) { throw "Stage $Stage profile $sfMode failed" }
    Write-Output "Stage $Stage $sfMode profile saved."
}
