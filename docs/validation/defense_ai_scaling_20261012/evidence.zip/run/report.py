from pathlib import Path
import csv, hashlib, json, re, statistics, subprocess, zipfile

repo=Path.cwd();root=repo/'shots/defense_ai_scaling_20261012';old=repo/'shots/projectile_scaling_20261012'
destination=repo/'docs/validation/defense_ai_scaling_20261012'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return p.read_text(encoding='utf-8-sig')
def data(p): return json.loads(read(p))
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
r={'baselineCommit':'36a7254','scope':'PD/drone target candidates, AI observed-missile threats, dominated sensor-ray rejection and exact shared terrain-exposure samples. Original ordering, live damage checks, observations, 60Hz/240Hz and ship data retained.', 'scale':[], 'extendedScale':{}, 'profiles':[], 'matrix':[], 'checks':{}, 'fps':{}}
for group in (1,2,4,10):
    variants={v:[data(root/f'scale-{group}-{n}-{v}.json')[0] for n in (1,2,3)] for v in ('before','after')}
    assert len({x['summarySha256'] for xs in variants.values() for x in xs})==1,(group,'scale outcome')
    result={'ships':group*24,'repeats':3,'resultsIdentical':True}
    for v,xs in variants.items():
        result[v]={k:statistics.median(x[k] for x in xs) for k in ('meanMs','p95Ms','p99Ms','maxMs','allocatedBytesPerTick','peakRails','peakMissiles','peakProbes')}
        result[v]['sectionsUs']={k:statistics.median(x['sectionsUs'][k] for x in xs) for k in xs[0]['sectionsUs']}
        result[v]['meanMsRange']=[min(x['meanMs'] for x in xs),max(x['meanMs'] for x in xs)]
    r['scale'].append(result)
for case in ('asteroid','late'):
    a,b=(data(root/f'{case}-{v}.json')[0] for v in ('before','after'))
    assert a['summarySha256']==b['summarySha256'],case
    r['extendedScale'][case]={'before':a,'after':b,'resultsIdentical':True,'repeats':1}
for mode in ('Annihilation','Flagship','Domination'):
    for field in (0,1,2,3):
        profile={'mode':mode,'field':field}
        for v in ('before','after'):
            prefix=f'profile-{mode}-field{field}-{v}'
            ticks={x['scope']:x for x in rows(root/(prefix+'.ticks.csv'))}
            sections={x['section']:float(x['usPerTick']) for x in rows(root/(prefix+'.sections.csv')) if x['scope']=='All'}
            profile[v]={'meanMs':float(ticks['All']['meanMs']),'brawlP99Ms':float(ticks['Brawl']['p99Ms']) if ticks.get('Brawl',{}).get('p99Ms') else None,'sectionsUs':sections}
        r['profiles'].append(profile)
        label=f'final-{mode}-field{field}'
        assert 'PASS: 20/20 battle summaries match' in read(root/(label+'.log')),label
        matching={}
        for suffix in ('summaries.json','ships.csv','am.csv','probes.csv','environment.csv','environment-events.csv','sight.csv','cover.csv','navigation.csv'):
            a,b=old/(label+'.'+suffix),root/(label+'.'+suffix)
            if suffix=='navigation.csv':
                normalized=lambda p:[{k:v for k,v in x.items() if k not in ('buildMs','planMs')} for x in rows(p)]
                matching[suffix]=normalized(a)==normalized(b)
            else: matching[suffix]=a.read_bytes()==b.read_bytes()
            assert matching[suffix],(label,suffix)
        r['matrix'].append({'mode':mode,'field':field,'battles':20,'matches':matching})
r['summaryMatches']=sum(x['battles'] for x in r['matrix'])
r['stage1DeepSpaceMatches']={}
for mode in ('Annihilation','Flagship'):
    assert (repo/f'shots/environment_stage2/baseline-{mode}.summaries.json').read_bytes()==(root/f'final-{mode}-field0.summaries.json').read_bytes()
    r['stage1DeepSpaceMatches'][mode]=20
r['pairedBlock']=data(root/'final-inprocess-block.json');assert len(r['pairedBlock'])==5
r['slowDiagnostic']=data(root/'slow-asteroid.json')[0]
assert r['slowDiagnostic']['summarySha256']==r['extendedScale']['asteroid']['after']['summarySha256']
for file in ('final-sim.log','native-flow-test.log','native-environment-test.log'):
    text=read(root/file);assert 'PASS:' in text and not re.search('Unhandled exception|ERROR:',text),file
    checks=re.findall(r'PASS: (\d+) ([^\r\n]+)',text)
    r['checks'][file]={'total':sum(int(n) for n,_ in checks),'groups':checks}
for p in root.glob('fps-*.log'):
    text=read(p);assert not re.search('ERROR:|Exception',text),p
    samples=[{'time':int(t),'fps':float(f)} for t,f in re.findall(r'perf t=(\d+)s fps=([\d.]+)',text) if 590<=int(t)<=615]
    assert samples,p
    r['fps'][p.name]={'mean':statistics.mean(x['fps'] for x in samples),'minimum':min(x['fps'] for x in samples),'samples':samples,'build':re.search('perf build:.*',text).group()}
assert len(r['fps'])==6
for x in data(root/'sim-source-hashes.json'):
    assert sha(repo/'src/Sim'/x['Name']).upper()==x['Hash'].upper(),'Simulation changed after freeze'
assert subprocess.run(['git','diff','--quiet','36a7254','--','data/ships'],cwd=repo).returncode==0
r['shipDataUnchangedFromBaseline']=True
r['sources']={str(p.relative_to(repo)).replace('\\','/'):sha(p) for folder in ('src','tests/SimChecks','tools/ScaleBench') for p in (repo/folder).rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
for p in list((repo/'data/ships').glob('*.json'))+list((repo/'src/Sim').glob('*.cs.uid'))+[repo/'SpaceFleet.csproj',repo/'src/Sim/SpaceFleet.Sim.csproj',repo/'tools/ScaleBench/ScaleBench.csproj']:
    r['sources'][str(p.relative_to(repo)).replace('\\','/')]=sha(p)
r['runnerHashes']={name:sha(root/name/file) for name,file in (('baseline-runner','BattleBatch.dll'),('final-runner','BattleBatch.dll'),('scale-before','ScaleBench.dll'),('scale-after','ScaleBench.dll'))}
build=repo/'builds/SpaceFleet-20261012-defense-scaling-Windows-x64';archive=build.with_suffix('.zip')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert any(p.endswith('/SpaceFleet.Sim.dll') for p in z.namelist())
r['build']=data(build/'build-info.json')
r['build'].update(zipSha256=sha(archive),zipBytes=archive.stat().st_size,zipCrcVerified=True)
r['nativeExportChecks']=sum(int(n) for line in r['build']['checks'] for n in re.findall(r'PASS: (\d+)',line))
r['limitations']=[
 'Scale cases are synthetic Earth/Earth in one shared SimWorld, 40km start. They do not establish 240-ship rendered multiplayer FPS.',
 'Main sizes use three isolated before/after repetitions with alternating order; extended asteroid seed2 and late 180-240s cases each use one before/after pair.',
 'The fresh six-run native FPS set measures the standard 24-ship scene at 4x simulation speed, not 240 ships. Release before/after cases are consecutive but single pairs.',
 'Native Debug has optimized Sim but unoptimized game/view; actual JIT flags are stored with every FPS log.',
 'The six-job 240-battle matrix validates behavior only, not performance. Navigation comparison excludes nondeterministic buildMs/planMs only.',
 'Development-only detail/pd/trial/drone/terrain-trial measurements and the defense-only directory precede the final sensor/terrain changes; they do not feed the final tables.',
 'Other hardware, large multiplayer networking/render/audio load, longer battles, other large-scene design mixes and manual play feel remain unverified.'
]
destination.mkdir(parents=True,exist_ok=True)
evidence=[]
for p in root.iterdir():
    if p.is_file() and p.suffix in ('.log','.json','.csv','.py','.ps1'): evidence.append((p,'run/'+p.name))
for p in (root/'defense-only').iterdir():
    if p.is_file() and p.suffix in ('.log','.json'):evidence.append((p,'development-defense-only/'+p.name))
for p in old.glob('final-*'):
    if p.suffix in ('.csv','.json'): evidence.append((p,'baseline/'+p.name))
for p in (repo/('shots/'+build.name)).glob('*.log'):
    assert not re.search('ERROR:|Exception',read(p)),p
    evidence.append((p,'export/'+p.name))
with zipfile.ZipFile(destination/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in evidence:z.write(p,name)
    z.write(repo/'shots/environment_stage1/paired-block/Program.cs','paired-block/Program.cs')
r['evidenceSha256']=sha(destination/'evidence.zip')
(destination/'verification.json').write_text(json.dumps(r,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'scale':[{k:v for k,v in x.items() if k in ('ships','before','after')} for x in r['scale']],'extendedScale':r['extendedScale'],'checks':r['checks'],'fps':r['fps'],'nativeExportChecks':r['nativeExportChecks']},ensure_ascii=False,indent=2))
