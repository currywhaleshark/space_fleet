import csv, collections, hashlib, json, re, subprocess, zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
repo=root.parents[1]
old=repo/'shots/environment_stage2'
destination=repo/'docs/validation/environment_stage2_optimization_20261012'
destination.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((root/'metrics.json').read_text(encoding='utf-8'))
report.update(baselineCommit='eeb7927',environmentStage1Commit='6629d2e',
    sourceBaseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    runnerSha256=sha(root/'runner/BattleBatch.dll'),
    beforeRunnerSha256=sha(old/'stage6-runner/BattleBatch.dll'),
    matrix=[],summaryMatches=0,untouchedBalance=True,
    measurementNotes=[
        'Performance profiles run serially, jobs=1; DeepSpace/current then asteroid/before then asteroid/current. No validation batch or game concurrently.',
        'Matrix latency is not performance evidence. All final groups use jobs=6.',
        'Debug game/view remains MinOpts; simulation is an optimized separate assembly with portable PDB. This build change contributes to FPS gains.',
        'pass5/pass6/detail measurements overlap a separately running user game and are excluded. That game exited before final profiles/FPS.',
        'Rejected per-wreck-group BVH query experiment (pass3) increased cost and is absent from final source.',
        'Rejected small-target prefilter regressed empty-space CPU-affinity-4 measurements by 2.1-4.5%. It was removed; full five-pair no-small results use the exact final simulation runner.',
        'Manual piloting/camera/cover feel was not verified.'
    ])
report['measurementNotes'].append('The first exported combat-visual-test timed out at 45 seconds with an empty engine log during the regression batch. All 11 checks were rerun on the same executable after the batch, allowing 120 seconds for startup; the first attempt is retained.')
suffixes=('summaries.json','ships.csv','am.csv','probes.csv','environment.csv','environment-events.csv','navigation.csv','sight.csv','cover.csv')
evidence=[]
for mode in ('Annihilation','Flagship','Domination'):
    for field in (0,1,2,3):
        a='stage6-'+mode if not field else f'stage6-asteroid-{mode}-field{field}'
        b=f'final-{mode}-field{field}'
        log=(root/(b+'.log')).read_text(encoding='utf-8-sig')
        assert 'PASS: 20/20 battle summaries match' in log,b
        comparisons={}
        for suffix in suffixes:
            before,after=old/(a+'.'+suffix),root/(b+'.'+suffix)
            if suffix=='navigation.csv':
                def deterministic_navigation(path):
                    with path.open(encoding='utf-8-sig',newline='') as stream:
                        return [{k:v for k,v in row.items() if k not in ('buildMs','planMs')} for row in csv.DictReader(stream)]
                comparisons[suffix]=deterministic_navigation(before)==deterministic_navigation(after)
            else:
                comparisons[suffix]=before.read_bytes()==after.read_bytes()
            assert comparisons[suffix],(b,suffix)
            evidence.append((before,'before/'+before.name))
        summaries=json.loads((root/(b+'.summaries.json')).read_text(encoding='utf-8-sig'))
        assert len(summaries)==20
        report['summaryMatches']+=len(summaries)
        report['matrix'].append(dict(mode=mode,field=field,battles=20,identical=comparisons))
assert report['summaryMatches']==240
report['navigationExcludedTimingColumns']=['buildMs','planMs']
report['stage1DeepSpaceMatches']={}
for mode in ('Annihilation','Flagship'):
    before=old/f'baseline-{mode}.summaries.json'
    after=root/f'final-{mode}-field0.summaries.json'
    assert before.read_bytes()==after.read_bytes(),('stage1 baseline',mode)
    report['stage1DeepSpaceMatches'][mode]=20
    evidence.append((before,'stage1-baseline/'+before.name))
report['pairedBlock']=json.loads((root/'final-inprocess-block.json').read_text(encoding='utf-8-sig'))
assert len(report['profiles'])==9 and len(report['fps'])==4
assert all(x['errors']==0 for x in report['fps'].values()),'FPS run has errors'
with (root/'final-slow.1-False.slow-ticks.csv').open(encoding='utf-8-sig',newline='') as stream:
    slow=list(csv.DictReader(stream))
sections=['AI','Gunnery','ShipStep','Collision','Projectiles','Missiles','PointDefense','Drones','Sensors','Probes','Post']
brawl=[r for r in slow if r['phase']=='Brawl']
report['slowTickDiagnostic']=dict(totalRetained=len(slow),brawlRetained=len(brawl),dominantSections=dict(collections.Counter(max(sections,key=lambda k:float(r[k])) for r in brawl)))
build=repo/'builds/SpaceFleet-20261012-environment-stage2-optimized-Windows-x64'
archive=build.with_suffix('.zip')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert any(p.endswith('/SpaceFleet.Sim.dll') for p in z.namelist())
    assert not any('/src/Sim/bin/' in p or '/src/Sim/obj/' in p for p in z.namelist())
report['build']=json.loads((build/'build-info.json').read_text(encoding='utf-8-sig'))
report['build']['zipSha256']=sha(archive)
report['build']['zipBytes']=archive.stat().st_size
report['build']['zipCrcVerified']=True
pck=(build/'SpaceFleet.pck').read_bytes()
assert b'src/Sim/bin/' not in pck and b'src/Sim/obj/' not in pck
report['build']['pckNoIntermediatePaths']=True
report['build']['assemblyHashes']={p.name:sha(p) for p in build.rglob('SpaceFleet*.dll')}
report['sources']={str(p.relative_to(repo)).replace('\\','/'):sha(p) for folder,glob in [('src','*.cs'),('data/ships','*.json'),('tests/SimChecks','*.cs'),('tools/BattleBatch','*.cs')] for p in (repo/folder).rglob(glob) if 'obj' not in p.parts and 'bin' not in p.parts}
for p in (repo/'SpaceFleet.csproj',repo/'src/Sim/SpaceFleet.Sim.csproj',repo/'src/Sim/AssemblyInfo.cs.uid',repo/'tools/windows-export.cfg'):
    report['sources'][str(p.relative_to(repo)).replace('\\','/')]=sha(p)
frozen=json.loads((root/'final-sim-source-hashes.json').read_text(encoding='utf-8-sig'))
assert all(sha(Path(item['path'])).lower()==item['sha256'].lower() for item in frozen),'Simulation changed after runner freeze'
exportLogs=repo/('shots/'+build.name)
for p in exportLogs.glob('*.log'):
    text=p.read_text(encoding='utf-8-sig')
    assert not re.search(r'ERROR:|Exception',text),p
    evidence.append((p,'export/'+p.name))
report['nativeExportChecks']=sum(int(n) for group in report['build']['checks'] for n in re.findall(r'PASS: (\d+)',group))
for p in root.iterdir():
    if p.is_file() and (p.suffix in ('.log','.json','.csv','.ps1','.py')):
        evidence.append((p,'optimization/'+p.name))
for p in (root/'rejected-small-sweep').glob('*'):
    if p.is_file() and p.suffix in ('.log','.json','.csv'):
        evidence.append((p,'rejected-small-sweep/'+p.name))
assert sha(root/'runner/BattleBatch.dll')==sha(root/'no-small-runner/BattleBatch.dll'),'Paired block runner differs'
for p in (root/'runner/BattleBatch.dll',old/'stage6-runner/BattleBatch.dll'):
    evidence.append((p,'runners/'+('current-' if p.parent.name=='runner' else 'before-')+p.name))
with zipfile.ZipFile(destination/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,name in sorted(set(evidence),key=lambda x:x[1]):z.write(path,name)
    z.write(repo/'shots/environment_stage1/paired-block/Program.cs','paired-block/Program.cs')
with zipfile.ZipFile(destination/'evidence.zip') as z:assert z.testzip() is None
report['evidenceSha256']=sha(destination/'evidence.zip')
(destination/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(summaryMatches=report['summaryMatches'],simChecks=report['checks']['final-sim.log']['total'],exportChecks=report['nativeExportChecks'],zipSha256=report['build']['zipSha256'],evidenceSha256=report['evidenceSha256']),indent=2))
